f=open('data/TREC/TREC_10.label','r')
i=0
length=0
for line in f:
    i+=1
    length+=len(line.split())
print(length/i)