# -*- coding: utf-8 -*-

from keras.models import load_model
import keras
from params import Params
from dataset import qa
import keras.backend as K
from keras.layers import Lambda
import pandas as pd
from layers.loss import *
from layers.loss.metrics import precision_batch
from tools.units import to_array, getOptimizer,parse_grid_parameters
import argparse
import itertools
from numpy.random import seed
from tensorflow import set_random_seed
import tensorflow as tf
import os
import random
from models import match as models
from tools.evaluation import matching_score, write_to_file
from check_result_in_phone import send_result_to_email

#加载模型
from keras.models import load_model
from params import Params
from dataset import qa
from layers import *

from layers.qwm_ngram import qwm_ngram
from layers.cvnn.qwm_measurement import Complex_QWM_Measurement
from layers.loss.triplet_hinge_loss_transfer import Circle_loss

from layers.loss import *
from layers.loss.metrics import precision_batch
from tools.units import to_array
from tools.evaluation import matching_score

def run(params,reader,result_file,best_model_file):
    f = open(result_file, 'a')
    f.write(params.to_string()+'\n')
    f.write(best_model_file+'\n')
    f.close()
    # load_model_test()

    #result_file = "result/wiki-qa/2020418_newmodel（wiki,qwm-ngram,weighted_circle_loss,2-weight,probs_list_L2归一化）.txt"
    #best_metric = 0.68


    best_MAP=0
    best_MAP_list=[]
    best_MRR=0
    best_MRR_list=[]

    test_data = reader.getTest(iterable = False, mode = 'test')
    dev_data = reader.getTest(iterable = False, mode = 'dev')
    qdnn = models.setup(params)
    model = qdnn.getModel()

    performance = []
    data_generator = None
    if 'onehot' not in params.__dict__:
        params.onehot = 0

    if params.match_type == 'pointwise':
        test_data = [to_array(i,reader.max_sequence_length) for i in test_data]
        dev_data = [to_array(i,reader.max_sequence_length) for i in dev_data]
        if params.onehot:
            loss_type,metric_type = ("categorical_hinge","acc")
        else:
            loss_type,metric_type = ("mean_squared_error","mean_squared_error")

        model.compile(loss =loss_type, #""
                optimizer = getOptimizer(name=params.optimizer,lr=params.lr),
                metrics=[metric_type])
        data_generator = reader.get_pointwise_samples(onehot = params.onehot)
#            if "unbalance" in  params.__dict__ and params.unbalance:
#                model.fit_generator(reader.getPointWiseSamples4Keras(onehot = params.onehot,unbalance=params.unbalance),epochs = 1,steps_per_epoch=int(len(reader.datas["train"])/reader.batch_size),verbose = True)
#            else:
#                model.fit_generator(reader.getPointWiseSamples4Keras(onehot = params.onehot),epochs = 1,steps_per_epoch=len(reader.datas["train"]["question"].unique())/reader.batch_size,verbose = True)

    elif params.match_type == 'pairwise':
        test_data.append(test_data[0])  # fill a placeholder for the first parameter
        test_data.append(test_data[0])
        test_data.append(test_data[0])
        test_data = [to_array(i, reader.max_sequence_length) for i in test_data]
        dev_data.append(dev_data[0])
        #dev_data.append(dev_data[0])
        dev_data = [to_array(i, reader.max_sequence_length) for i in dev_data]
        model.compile(loss=identity_loss,
                      optimizer=getOptimizer(name=params.optimizer, lr=params.lr),
                      metrics=[precision_batch],
                      loss_weights=[0.0,1.0,1.0])
        model.summary()
        # keras.utils.plot_model(model,'model.png',show_shapes=True)
        data_generator = reader.get_pairwise_samples()

    print('Training the network:')
    for i in range(params.epochs):
        f = open(result_file, 'a')
        #fit_generator的作用是，利用Python的生成器，逐个生成数据的batch,并且进行训练。
        #需要注意的是生成器和模型将并行执行以提高效率。
        #例如，该函数允许我们在cpu上进行实施的数据提升，同时在GPU上进行模型训练。
        #参数：
        #1、generator:生成器函数，生成器的输出应该是：·一个形如（inputs,targets）的tuple;·一个形如（inputs,targets,ssample_weight）的tuple
        #1、generator中的所有的返回值应该包含相同数目的样本。生成器将无限在数据集上循环。每个epoch以经过模型的样本数达到samples_per_epoch，记一个epoch结束。
        #2、steps_per_epoch:整数，当生成器返回steps_per_epoch次数据时，记一个epoch结束，执行下一个epoch.
        #3、epochs：指的是数据迭代的轮数
        model.fit_generator(data_generator,epochs = 1,steps_per_epoch=int(len(reader.datas["train"]["question"].unique())/reader.batch_size),verbose = True)

        # # 获得某一层的权重和偏置
        # weight_Dense_1, bias_Dense_1 = model.get_layer('complex_qwm__measurement_1').get_weights()
        # test1=weight_Dense_1[0]
        # print("mazan",test1)

        # print('Validation Performance:')
        # y_pred = model.predict(x = dev_data)  #返回一个列表，列表的长度为3.   #print("y_pred",y_pred[0].shape)      #(1134,1)
        # score = matching_score(y_pred, params.onehot, params.match_type)
        # dev_metric = reader.evaluate(score, mode = "dev")
        # print(dev_metric)
        f.write(str(i+1)+'\n')
        # f.write(str(dev_metric)+'\n')

        print('Test Performance:')
        y_pred = model.predict(x = test_data)
        score = matching_score(y_pred, params.onehot, params.match_type)
        test_metric = reader.evaluate(score, mode = "test")
        print(test_metric)

        # #准确率高的模型的保存
        # if test_metric[1] > best_metric:
        #     model.save("temp/best.h5")

        f.write(str(test_metric)+'\n')
        f.close()
        if(test_metric[0]>best_MAP):
            best_MAP=test_metric[0]
            best_MAP_list=test_metric
        if(test_metric[1]>best_MRR):
            best_MRR=test_metric[1]
            best_MRR_list=test_metric
            model.save(best_model_file)
        performance.append(best_MAP_list+best_MRR_list)


    print('Done.')
    f = open(result_file, 'a')
    f.write('MAPbest:'+str(best_MAP_list)+'    MRRbest:'+str(best_MRR_list)+'\n')
    f.close()
    send_result_to_email(result_file)
    return performance



if __name__ == '__main__':

    params = Params()
    parser = argparse.ArgumentParser(description='Running the Complex-valued Network for Matching.')
    parser.add_argument('-gpu_num', action = 'store', dest = 'gpu_num', help = 'please enter the gpu num.',default=1)
    parser.add_argument('-gpu', action = 'store', dest = 'gpu', help = 'please enter the gpu num.',default=0)
    parser.add_argument('-config', action = 'store', dest = 'config', help = 'please enter the config path.',default='config/qalocal_pair_trec.ini')
    parser.add_argument('-grid_search',action = 'store', dest = 'grid_search',type = bool, help = 'please enter yes for grid search of parameters.', default=False)
    parser.add_argument('-grid_param_file',action = 'store', dest = 'config_grid',help = 'please enter the file storing parameters for ablation', default = 'config/grid_parameters.ini')
    args = parser.parse_args()
    params.parse_config(args.config)

#   Reproducibility Setting
    seed(params.seed)
    set_random_seed(params.seed)
    random.seed(params.seed)

    session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
    sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
    K.set_session(sess)
    #创建一个TensorFlow会话并且注册Keras。这意味着Keras将使用我们注册的会话来初始化它在内部创建的所有变量。
    #keras的层和模型都充分兼容tensorflow的各种scope, 例如name scope，device scope和graph scope。

    file_writer = open(params.output_file,'a')
    if args.grid_search:
        print('Grid Search Begins.')
        grid_parameters = parse_grid_parameters(args.config_grid)
        print(grid_parameters)
        parameters= [arg for index,arg in enumerate(itertools.product(*grid_parameters.values())) if index%args.gpu_num==args.gpu]
        result_dir = 'result/trec-qa/2020521_'
        result_name='.txt'
        j=0
        for parameter in parameters:
            print(parameter)
            j+=1
            # for i in range(3):
            result_file = result_dir + str(j)+ result_name
            best_model_file = 'temp/grid_best' + str(j) + '.h5'
            params.setup(zip(grid_parameters.keys(), parameter))
            reader = qa.setup(params)
            performance = run(params, reader, result_file, best_model_file)
            write_to_file(file_writer, params.to_string(), performance)
            K.clear_session()
#当您连续创建多个模型时，例如在超参数搜索或交叉验证期间，K.clear_session（）非常有用。
    # 您训练的每个模型都会将节点（可能以数千个编号）添加到图形中。只要您（或Keras）调用tf.Session.run（）或tf.Tensor.eval（），
    # TensorFlow就会执行整个图形，因此您的模型将变得越来越慢，并且您可能也会耗尽内存。清除会话将删除以前模型遗留的所有节点，释放内存并防止减速。
    else:
        result_file='result/trec-qa/2020612(zheng_xiang_weight).txt'
        reader = qa.setup(params)
        # model = load_model('temp/27best.h5',
        #                    custom_objects={'NGram': NGram, 'L2Normalization': L2Normalization, 'qwm_ngram': qwm_ngram,
        #                                    "Complex_QWM_Measurement": Complex_QWM_Measurement,
        #                                    "ComplexMultiply": ComplexMultiply, "ComplexMixture": ComplexMixture,
        #                                    "Concatenation": Concatenation, "Cosine": Cosine, "Circle_loss": Circle_loss,
        #                                    "identity_loss": identity_loss, "precision_batch": precision_batch})

        #performance = run(model,params, reader,result_file,best_model_file='temp/best.h5')
        performance = run( params, reader, result_file, best_model_file='temp/best.h5')
        write_to_file(file_writer,params.to_string(),performance)
        K.clear_session()
#model.save("temp/best.h5")
