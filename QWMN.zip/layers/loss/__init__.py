# -*- coding: utf-8 -*-
from .triplet_loss import rank_hinge_loss,precision,positive,negative
from .pairwise_loss import identity_loss,pointwise_loss,hinge,batch_pairwise_loss,categorical_hinge