# -*- coding: utf-8 -*-

import numpy as np
from keras import backend as K
import tensorflow as tf
from keras.layers import Layer,Activation,Lambda
from keras.models import Model, Input
import math


class qwm_ngram(Layer):

    def __init__(self, axis=2, keep_dims=True, **kwargs):
        # self.output_dim = output_dim
        self.axis = axis
        self.keep_dims = keep_dims
        super(qwm_ngram, self).__init__(**kwargs)

    def get_config(self):
        config = {'axis': self.axis, 'keep_dims': self.keep_dims}
        base_config = super(qwm_ngram, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))

    def build(self, input_shape):

        # Create a trainable weight variable for this layer.

        # self.kernel = self.add_weight(name='kernel',
        #                               shape=(input_shape[1], self.output_dim),
        #                               initializer='uniform',
        #                               trainable=True)
        super(qwm_ngram, self).build(input_shape)  # Be sure to call this somewhere!

    def call(self, inputs):

        #        output = K.sqrt(K.sum(inputs**2, axis = self.axis, keepdims = self.keep_dims))
        # output = K.sqrt(0.00001 + K.sum(inputs ** 2, axis=self.axis, keepdims=self.keep_dims))
        #print("inputs.shape",inputs.shape)
        n_value = int(inputs.shape[2])

        half_n_value = math.floor(n_value / 2)
        #print("half_n_value", half_n_value)  # (?, 42, 5, 50)
        a = K.sum(K.slice(inputs, [0, 0, 0, 0], [-1, -1, half_n_value, -1]), axis=2, keepdims=self.keep_dims)
        print("vcvcv",a.shape)
        history_state = K.expand_dims(a)  # (?,42,1,50,1)
        #print("history", history_state)
        current_state = K.slice(inputs, [0, 0, half_n_value, 0], [-1, -1, 1, -1])  # (?,42,1,50)
        future_state = K.expand_dims(
            K.sum(K.slice(inputs, [0, 0, half_n_value + 1, 0], [-1, -1, n_value - half_n_value - 1, -1]), axis=2,
                  keepdims=self.keep_dims))  # (?,42,1,50,1)
        #print("current",current_state)
        #print("future_state",future_state)
        #求信息需求状态（current的外积）
        current_state_transpose=K.expand_dims(current_state)     #？，42,1,50,1
        #print("current_state_transpose",current_state_transpose)
        current_state1=K.expand_dims(current_state,axis=3)      #？，42,1,1,50
        #print("current_state1",current_state1)
        current_state_info=K.batch_dot(current_state1,current_state_transpose,axes=[3,4])    #？，42,1,50,50
        #print("current_info",current_state_info)
        #求弱值
        b=K.batch_dot(current_state_info,history_state,axes=[4,3])   #
        #print("b",b)
        c=K.batch_dot(future_state,b,axes=[3, 3])
        #print("c",c)
        son=tf.squeeze(c,[2,3,4])+0.00001
        #print("son",son)
        d=K.batch_dot(future_state,history_state,axes=[3,3])
        #print("d",d)
        mother=tf.squeeze(d,[2,3,4])+0.00001    #?,42,1,1,1
        #print("mother",mother)
        weak_value=son/mother      #?,42
#tf.squeeze()该函数返回一个张量，这个张量是将原始input中所有维度为1的那些维都删掉的结果
#axis可以用来指定要删掉的为1的维度，此处要注意指定的维度必须确保其是1，否则会报错
        print("weak_values_test",weak_value)

        # 求反向弱值
        # b2 = K.batch_dot(current_state_info, future_state, axes=(4, 3))  # ?,42,1,50,1
        # print("b2", b2)
        # c2 = K.batch_dot(history_state, b2, axes=(3, 3))
        # print("c2", c2)
        # son2 = tf.squeeze(c2, [2, 3, 4]) + 0.00001
        # print("son2", son2)
        #
        # # d=K.batch_dot(future_state,history_state,axes=(3,3))
        # d2 = K.batch_dot(history_state, future_state, axes=(3, 3))
        # print("d2", d2)
        # mother2 = tf.squeeze(d2, [2, 3, 4]) + 0.00001  # ?,42,1,1,1
        # print("mother2", mother2)
        # weak_value2 = son2 / mother2  # ?,42

        #正反两个方向的权值整合到一起
        # def plus_score(inputs):
        #     x1 = inputs[0]
        #     x2 = inputs[1]
        #     print("x1.shape", x1.shape)
        #     return K.maximum(x1, x2)
        #
        # # weak_value=(weak_value+weak_value2)/2
        # weak_value = Lambda(plus_score)([weak_value, weak_value2])

        #再将计算好的弱值进行ngram划分，从而得到42个包含局部信息的密度矩阵表示。在这里得到一个42×n_value的弱值矩阵
        seq_len=int(weak_value.shape[1])
        list_of_ngrams = []
        for i in range(n_value):
            begin = max(0, i - math.floor(n_value / 2))
            end = min(seq_len - 1 + i - math.floor(n_value / 2), seq_len - 1)
            #            print(begin,end)
            l = K.slice(weak_value, [0, begin], [-1, end - begin + 1])
            #            print(l.shape)
            padded_zeros = K.zeros_like(K.slice(weak_value, [0, 0], [-1, int(
                seq_len - (end - begin + 1))]))  # "begin"是每一个维度的起始位置，这个下面详细说，"size"相当于每个维度拿几个元素出来。
            #            print(padded_zeros.shape)
            # 创建一个所有元素都设置为零的张量.给定一个张量(tensor),该操作返回与所有元素设置为零的tensor具有相同类型和形状的张量.或者,您可以使用dtype指定返回张量的新类型.
            if begin == 0:
                # left_padding
                list_of_ngrams.append(K.expand_dims(K.concatenate([padded_zeros, l])))
                # right_padding
            else:
                list_of_ngrams.append(K.expand_dims(K.concatenate([l, padded_zeros])))

        ngram_weakvalue_mat = K.concatenate(list_of_ngrams, axis=-1)

        # if n_value % 2 == 0:
        #     half_n_value2 = math.floor(n_value / 2)
        #     # print("half_n_value", half_n_value)  # (?, 42, 5, 50)
        #     a2 = K.sum(K.slice(inputs, [0, 0, 0, 0], [-1, -1, half_n_value2 - 1, -1]), axis=2,
        #                keepdims=self.keep_dims)
        #     history_state = K.expand_dims(a2)  # (?,42,1,50,1)
        #     # print("history", history_state)
        #     current_state = K.slice(inputs, [0, 0, half_n_value2-1, 0], [-1, -1, 1, -1])  # (?,42,1,50)
        #     future_state = K.expand_dims(
        #         K.sum(K.slice(inputs, [0, 0, half_n_value2, 0], [-1, -1, half_n_value2, -1]), axis=2,
        #               keepdims=self.keep_dims))  # (?,42,1,50,1)
        #
        #     current_state_transpose = K.expand_dims(current_state)  # ？，42,1,50,1
        #     # print("current_state_transpose",current_state_transpose)
        #     current_state1 = K.expand_dims(current_state, axis=3)  # ？，42,1,1,50
        #     # print("current_state1",current_state1)
        #     current_state_info = K.batch_dot(current_state1, current_state_transpose, axes=[3, 4])  # ？，42,1,50,50
        #
        #     b2 = K.batch_dot(current_state_info, future_state, axes=(4, 3))  # ?,42,1,50,1
        #     print("b2", b2)
        #     c2 = K.batch_dot(history_state, b2, axes=(3, 3))
        #     print("c2", c2)
        #     son2 = tf.squeeze(c2, [2, 3, 4]) + 0.00001
        #     print("son2", son2)
        #
        #     # d=K.batch_dot(future_state,history_state,axes=(3,3))
        #     d2 = K.batch_dot(history_state, future_state, axes=(3, 3))
        #     print("d2", d2)
        #     mother2 = tf.squeeze(d2, [2, 3, 4]) + 0.00001  # ?,42,1,1,1
        #     print("mother2", mother2)
        #     weak_value2 = son2 / mother2  # ?,42
        #
        #     # 反向的
        #     seq_len2 = int(weak_value2.shape[1])
        #     list_of_ngrams2 = []
        #     for i in range(n_value):
        #         begin = max(0, i - math.floor(n_value / 2))
        #         end = min(seq_len2 - 1 + i - math.floor(n_value / 2), seq_len2 - 1)
        #         #            print(begin,end)
        #         l = K.slice(weak_value2, [0, begin], [-1, end - begin + 1])
        #         #            print(l.shape)
        #         padded_zeros = K.zeros_like(K.slice(weak_value2, [0, 0], [-1, int(
        #             seq_len2 - (end - begin + 1))]))  # "begin"是每一个维度的起始位置，这个下面详细说，"size"相当于每个维度拿几个元素出来。
        #         #            print(padded_zeros.shape)
        #         # 创建一个所有元素都设置为零的张量.给定一个张量(tensor),该操作返回与所有元素设置为零的tensor具有相同类型和形状的张量.或者,您可以使用dtype指定返回张量的新类型.
        #         if begin == 0:
        #             # left_padding
        #             list_of_ngrams2.append(K.expand_dims(K.concatenate([padded_zeros, l])))
        #             # right_padding
        #         else:
        #             list_of_ngrams2.append(K.expand_dims(K.concatenate([l, padded_zeros])))
        #     ngram_weakvalue_mat2 = K.concatenate(list_of_ngrams2, axis=-1)
        #     return [ngram_weakvalue_mat,ngram_weakvalue_mat2]
        # else:
        #     return [ngram_weakvalue_mat,ngram_weakvalue_mat]
        return ngram_weakvalue_mat

    def compute_output_shape(self, input_shape):
        #        print(input_shape)
        # print(type(input_shape[1]))
        output_shape = []
        for i in range(len(input_shape)):
            if not i == self.axis:
                output_shape.append(input_shape[i])
        if self.keep_dims:
            output_shape.append(1)
        #        print('Input shape of L2Norm layer:{}'.format(input_shape))
        #        print(output_shape)
        return [tuple(output_shape)]


if __name__ == '__main__':
    from keras.layers import Input, Dense

    input_img = Input(shape=(42,6,50))
    # n = Dense(5)(input_img)        #42,5,5
    [output1,output2] = qwm_ngram(axis=3, keep_dims=True)(input_img)    #?，42

    o1 = Activation('softmax')(output1)   #5
    o2 = Activation('softmax')(output2)  # 5
    # baba=K.ones((42,1))
    # vd=tf.subtract(baba,output)
    encoder = Model(input_img,[o1,o2])
    encoder.compile(loss='mean_squared_error',
                    optimizer='rmsprop',
                    metrics=['accuracy'])
    #
    encoder.summary()
    a = (np.random.random((1,42,6,50))-0.5)*2.2
    print(encoder.predict(x=a))