import numpy as np
from keras import backend as K
from keras.layers import Layer,Activation
from keras.models import Model, Input
from keras.constraints import unit_norm
from keras.initializers import Orthogonal
from layers.l2_normalization import L2Normalization
import tensorflow as tf

class Complex_QWM_Measurement_ngram(Layer):

    def __init__(self, units=5, trainable=True, **kwargs):
        self.units = units
        self.trainable = trainable
        super(Complex_QWM_Measurement_ngram, self).__init__(**kwargs)
        self.measurement_constrain = unit_norm(axis=(1, 2))
        self.measurement_initalizer = Orthogonal(gain=1.0, seed=None)
        self.l2_normalization_2 = L2Normalization(axis=1)

    def get_config(self):
        config = {'units': self.units, 'trainable': self.trainable}
        base_config = super(Complex_QWM_Measurement_ngram, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))

    def build(self, input_shape):
        if not isinstance(input_shape, list):
            raise ValueError('This layer should be called '
                             'on a list of 2 inputs.')

        if len(input_shape) != 2:
            raise ValueError('This layer should be called '
                             'on a list of 2 inputs.'
                             'Got ' + str(len(input_shape)) + ' inputs.')
        self.dim = input_shape[0][-1]

        # self.kernel = self.add_weight(name='kernel',
        #                                       shape=(self.units, self.dim, 4),  # 300,50,2
        #                                       constraint=self.measurement_constrain,
        #                                       initializer=self.measurement_initalizer,
        #                                       trainable=self.trainable)

        self.history_kernel = self.add_weight(name='history_kernel',
                                      shape=(self.units, self.dim, 2),  # 300,50,2
                                      constraint=self.measurement_constrain,
                                      initializer=self.measurement_initalizer,
                                      trainable=self.trainable)

        self.future_kernel=self.add_weight(name='future_kernel',
                                      shape=(self.units, self.dim, 2),  # 300,50,2
                                      constraint=self.measurement_constrain,
                                      initializer=self.measurement_initalizer,
                                      trainable=self.trainable)

        super(Complex_QWM_Measurement_ngram, self).build(input_shape)  # Be sure to call this somewhere!

    def call(self, inputs):
        if not isinstance(inputs, list):
            raise ValueError('This layer should be called '
                             'on a list of 2 inputs.')

        if len(inputs) != 2:
            raise ValueError('This layer should be called '
                             'on a list of 2 inputs.'
                             'Got ' + str(len(inputs)) + ' inputs.')


        # his_r=K.expand_dims(self.kernel[:, :, 0]) #300,50,1
        # print("his_r1",his_r.shape)
        # his_i=K.expand_dims(self.kernel[:, :, 1])
        # future_real=self.kernel[:, :, 2]
        # future_imag=self.kernel[:, :, 3]

       #两个weight/
        his_real=self.history_kernel[:, :, 0]
        his_r = K.expand_dims(his_real)  # 300,50,1
        print("his_r1", his_r.shape)
        his_imag=self.history_kernel[:, :, 1]
        his_i = K.expand_dims(his_imag)
        future_real = self.future_kernel[:, :, 0]
        future_imag = self.future_kernel[:, :, 1]



        his_r_1=K.permute_dimensions(his_r,[0,2,1]) #300,1,50
        his_i_1=K.permute_dimensions(his_i,[0,2,1])
        print("his_r_1",his_r_1.shape)
        fu_r_1=K.expand_dims(future_real)   #300,50,1
        fu_i_1=K.expand_dims(future_imag)
        print("fu_r_1",fu_r_1.shape)

        input_real = inputs[0]      #(?,42,50,50)
        input_imag = inputs[1]
        print("input_real",input_real.shape)


        current_future_real=K.permute_dimensions(K.expand_dims(K.dot(input_real,K.transpose(future_real))-K.dot(input_imag,K.transpose(future_imag))),[0,1,3,2,4])  #?,42,300,50,1
        current_future_imag=K.permute_dimensions(K.expand_dims(K.dot(input_imag,K.transpose(future_real))+K.dot(input_real,K.transpose(future_imag))),[0,1,3,2,4])  #?,42,300,50,1
        print("current_future_real", current_future_real.shape)


        #https://blog.csdn.net/huml126/article/details/88739846
        print("his_r",his_r.shape)
        history_current_future_real=K.sum((current_future_real * his_r - current_future_imag * his_i),axis=3)     #？，42,300,1
        history_current_future_imag=K.sum((current_future_imag * his_r - current_future_real * his_i),axis=3)    #？，42,300,1
        print("history_current_future_real",history_current_future_real.shape)
        print("history_current_future_imag", history_current_future_imag.shape)

        #分母
        his_fu_real=K.squeeze(K.batch_dot(his_r_1,fu_r_1,axes=[2,1])-K.batch_dot(his_i_1,fu_i_1,axes=[2,1]),axis=2)
        his_fu_imag=K.squeeze(K.batch_dot(his_i_1,fu_r_1,axes=[2,1])+K.batch_dot(his_r_1,fu_i_1,axes=[2,1]),axis=2)   #300,1
        print("his_fu_real",his_fu_real.shape)

        complex_num = tf.complex(his_fu_real, his_fu_imag)
        complex_num_conj=tf.conj(complex_num)
        complex_num_conj_real=tf.real(complex_num_conj)
        complex_num_conj_imag = tf.imag(complex_num_conj)

        weak_value_son_real=history_current_future_real*complex_num_conj_real-history_current_future_imag*complex_num_conj_imag
        weak_value_son_imag=history_current_future_imag*complex_num_conj_real+history_current_future_real*complex_num_conj_imag

        weak_value_mother=his_fu_real**2+his_fu_imag**2

        weak_value_imag=K.squeeze(weak_value_son_imag / weak_value_mother,axis=3)
        weak_value_real = K.squeeze(weak_value_son_real / weak_value_mother, axis=3)

#思路1的第二种
        #weak_value=K.concatenate([weak_value_imag,weak_value_real],axis=1)
#思路2
        #weak_value=K.concatenate([weak_value_real,weak_value_imag],axis=-1)

        # weak_value=weak_value_real+weak_value_imag

        # history_future_real=K.dot()
        #
        # weak_value_real=
        print("weak_value_imag",weak_value_imag.shape)    #?,42,300

        #多任务学习的权重分配：
        # L2norm_real = K.sqrt(0.00001 + K.sum(weak_value_real ** 2, axis=self.axis, keepdims=self.keep_dims))
        # L2norm_imag = K.sqrt(0.00001 + K.sum(weak_value_imag ** 2, axis=self.axis, keepdims=self.keep_dims))

        weak_value_real=self.l2_normalization_2(weak_value_real)
        weak_value_imag=self.l2_normalization_2(weak_value_imag)

        #对过去和将来信息状态的向量 增加正则项，保证过去向量和未来向量的信息状态尽量一致。

        #未来向量的共轭转置
        complex_fu = tf.complex(fu_r_1, fu_i_1)    #(300,50,1)
        print("complex_fu",complex_fu.shape)
        complex_fu_conj = tf.conj(complex_fu)
        complex_fu_conj_real = tf.real(complex_fu_conj)
        print("complex_fu_conj_real", complex_fu_conj_real.shape)
        complex_fu_conj_imag = tf.imag(complex_fu_conj)
        print("complex_fu_conj_imag", complex_fu_conj_imag.shape)

        regu_son_real=K.sum(his_r*complex_fu_conj_real-his_i*complex_fu_conj_imag,axis=1)
        print("regu_son_real", regu_son_real.shape)
        regu_son_imag=K.sum(his_i*complex_fu_conj_real+his_r*complex_fu_conj_imag,axis=1)
        print("regu_son_imag", regu_son_imag.shape)

        #增加不同测量算子之间的差异性 增加正则项。保证未来向量内部之间差异尽可能大。
        fu_congj_real=K.transpose(K.squeeze(complex_fu_conj_real,axis=2))
        fu_congj_imag = K.transpose(K.squeeze(complex_fu_conj_imag, axis=2))
        print("fu_congj_real", fu_congj_real.shape)
        print("fu_congj_imag", fu_congj_imag.shape)

        #A*AH
        regu_real=K.dot(his_real,fu_congj_real)-K.dot(his_imag,fu_congj_imag)
        regu_imag=K.dot(his_imag,fu_congj_real)+K.dot(his_real,fu_congj_imag)
        print("regu_real", regu_real.shape)
        print("regu_imag", regu_imag.shape)

        return [weak_value_real,weak_value_imag]

    def compute_output_shape(self, input_shape):
        output_shape = [None]
        for i in input_shape[0][1:-2]:
            output_shape.append(i)
        output_shape.append(self.units)

#2020316添加
        # output_shape[1]=84

        #        output_shape = [input_shape[0][0:-3],self.units]

        #        print('Input shape of measurment layer:{}'.format(input_shape))
        #        print(output_shape)
        return [tuple(output_shape),tuple(output_shape)]


def main():
    input_1 = Input(shape=(42, 50, 50), dtype='float')
    input_2 = Input(shape=(42, 50, 50), dtype='float')
    output = Complex_QWM_Measurement(100)([input_1, input_2])

    model = Model([input_1, input_2], output)
    model.compile(loss='binary_crossentropy',
                  optimizer='sgd',
                  metrics=['accuracy'])
    model.summary()

    weights = model.get_weights()
    x_1 = np.random.random((16, 42, 50, 50))
    x_2 = np.random.random((16, 42, 50, 50))
    output = model.predict([x_1, x_2])
    print(output)
    for i in range(5):
        xy = x_1[i] + 1j * x_2[i]
        for j in range(3):
            m = weights[0][j, :, 0] + 1j * weights[0][j, :, 1]
            #            print(np.matmul(xy[0] ,np.outer(m,m)))
            #            result = np.absolute(np.trace(np.matmul(xy ,np.outer(m,m))))
            print(np.trace(np.matmul(xy[0], np.outer(m, m))))

    # complex_array = np.random.random((3,5,2))

    # norm_2 = np.linalg.norm(complex_array, axis = (1,2))

    # for i in range(complex_array.shape[0]):
    #     complex_array[i] = complex_array[i]/norm_2[i]
    # # complex_array()= complex_array / norm_2
    # # x_2 = np.random.random((3,5))

    # x = complex_array[:,:,0]
    # x_2 = complex_array[:,:,1]
    # y = np.array([[1],[1],[0]])
    # print(x)
    # print(x_2)

    # for i in range(1000):
    #     model.fit([x,x_2],y)
    # # print(model.get_weights())
    #     output = model.predict([x,x_2])
    #     print(output)
    # # print(output)


if __name__ == '__main__':
    main()
