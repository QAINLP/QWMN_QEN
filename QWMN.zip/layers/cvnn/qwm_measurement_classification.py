import numpy as np
from keras import backend as K
from keras.layers import Layer
from keras.models import Model, Input
from keras.constraints import unit_norm
from keras.initializers import Orthogonal,RandomNormal
from layers.l2_normalization import L2Normalization
import tensorflow as tf

from batch_dot_224 import batch_dot_224


class Complex_QWM_Measurement_single(Layer):

    def __init__(self, units=5, trainable=True, **kwargs):
        self.units = units
        self.trainable = trainable
        super(Complex_QWM_Measurement_single, self).__init__(**kwargs)
        self.measurement_constrain = unit_norm(axis=(1, 2))
        self.measurement_initalizer = Orthogonal(gain=1.0, seed=None)
        #self.measurement_initalizer = RandomNormal(seed=None)
        self.l2_normalization_2 = L2Normalization(axis=1)

    def get_config(self):
        config = {'units': self.units, 'trainable': self.trainable}
        base_config = super(Complex_QWM_Measurement_single, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))

    def build(self, input_shape):
        if not isinstance(input_shape, list):
            raise ValueError('This layer should be called '
                             'on a list of 2 inputs.')

        if len(input_shape) != 2:
            raise ValueError('This layer should be called '
                             'on a list of 2 inputs.'
                             'Got ' + str(len(input_shape)) + ' inputs.')
        self.dim = input_shape[0][-1]

        # self.kernel = self.add_weight(name='kernel',
        #                                       shape=(self.units, self.dim, 4),  # 100,50,4
        #                                       constraint=self.measurement_constrain,
        #                                       initializer=self.measurement_initalizer,
        #                                       trainable=self.trainable)

        self.history_kernel = self.add_weight(name='history_kernel',
                                      shape=(self.units, self.dim, 2),  # 30,50,2
                                      constraint=self.measurement_constrain,
                                      initializer=self.measurement_initalizer,
                                      trainable=self.trainable)

        self.future_kernel=self.add_weight(name='future_kernel',
                                      shape=(self.units, self.dim, 2),  # 30,50,2
                                      constraint=self.measurement_constrain,
                                      initializer=self.measurement_initalizer,
                                      trainable=self.trainable)

        super(Complex_QWM_Measurement_single, self).build(input_shape)  # Be sure to call this somewhere!

    def call(self, inputs):
        if not isinstance(inputs, list):
            raise ValueError('This layer should be called '
                             'on a list of 2 inputs.')

        if len(inputs) != 2:
            raise ValueError('This layer should be called '
                             'on a list of 2 inputs.'
                             'Got ' + str(len(inputs)) + ' inputs.')

        #一组weight
        # his_r=K.expand_dims(self.kernel[:, :, 0]) #100,50,1
        # print("his_r1",his_r.shape)
        # his_i=K.expand_dims(self.kernel[:, :, 1])
        # future_real=self.kernel[:, :, 2]
        # future_imag=self.kernel[:, :, 3]

       #两个weight/
        his_r = K.expand_dims(self.history_kernel[:, :, 0])  # 30,50,1
        print("his_r1", his_r.shape)
        his_i = K.expand_dims(self.history_kernel[:, :, 1])
        future_real = self.future_kernel[:, :, 0]
        future_imag = self.future_kernel[:, :, 1]


        his_r_1=K.permute_dimensions(his_r,[0,2,1]) #30,1,50
        his_i_1=K.permute_dimensions(his_i,[0,2,1])
        print("his_r_1",his_r_1.shape)
        fu_r_1=K.expand_dims(future_real)   #30,50,1
        fu_i_1=K.expand_dims(future_imag)
        print("fu_r_1",fu_r_1.shape)

        input_real = inputs[0]      #(?,50,50)
        input_imag = inputs[1]
        print("input_real",input_real.shape)


        current_future_real=K.permute_dimensions(K.expand_dims(K.dot(input_real,K.transpose(future_real))-K.dot(input_imag,K.transpose(future_imag))),[0,2,1,3])  #?,30,50,1
        current_future_imag=K.permute_dimensions(K.expand_dims(K.dot(input_imag,K.transpose(future_real))+K.dot(input_real,K.transpose(future_imag))),[0,2,1,3])  #?,30,50,1
        print("current_future_real", current_future_real.shape)


        #https://blog.csdn.net/huml126/article/details/88739846
        print("his_r",his_r.shape)      #(30,50,1)
        history_current_future_real=K.sum((current_future_real * his_r - current_future_imag * his_i),axis=2)     #？,30,1
        history_current_future_imag=K.sum((current_future_imag * his_r + current_future_real * his_i),axis=2)    #？，30,1
        print("history_current_future_real",history_current_future_real.shape)
        print("history_current_future_imag", history_current_future_imag.shape)

        #分母
        his_fu_real=K.squeeze(batch_dot_224(his_r_1,fu_r_1,axes=[2,1])-batch_dot_224(his_i_1,fu_i_1,axes=[2,1]),axis=2)
        his_fu_imag=K.squeeze(batch_dot_224(his_i_1,fu_r_1,axes=[2,1])+batch_dot_224(his_r_1,fu_i_1,axes=[2,1]),axis=2)   #30,1
        print("his_fu_real",his_fu_real.shape)

        complex_num = tf.complex(his_fu_real, his_fu_imag)
        complex_num_conj=tf.conj(complex_num)
        complex_num_conj_real=tf.real(complex_num_conj)
        complex_num_conj_imag = tf.imag(complex_num_conj)

        weak_value_son_real=history_current_future_real*complex_num_conj_real-history_current_future_imag*complex_num_conj_imag   #(?,30,1) * (30,1)
        weak_value_son_imag=history_current_future_imag*complex_num_conj_real+history_current_future_real*complex_num_conj_imag

        weak_value_mother=his_fu_real**2+his_fu_imag**2

        weak_value_imag=K.squeeze(weak_value_son_imag / weak_value_mother,axis=2)
        weak_value_real = K.squeeze(weak_value_son_real / weak_value_mother, axis=2)

        #weak_value=K.concatenate([weak_value_imag,weak_value_real],axis=1)

        # weak_value=weak_value_real+weak_value_imag

        #weak_value_real = self.l2_normalization_2(weak_value_real)
        #weak_value_imag = self.l2_normalization_2(weak_value_imag)

        #weak_value = K.concatenate([weak_value_imag, weak_value_real], axis=1)

        print("weak_value_imag",weak_value_imag.shape)
        return [weak_value_real,weak_value_imag]
        #return weak_value

    def compute_output_shape(self, input_shape):

        output_shape = [None]
        for i in input_shape[0][1:-2]:
            output_shape.append(i)
        output_shape.append(self.units)
#2020316添加
        # output_shape[1]=84

        #        output_shape = [input_shape[0][0:-3],self.units]

        #        print('Input shape of measurment layer:{}'.format(input_shape))
        #        print(output_shape)

        #return [tuple(output_shape)]

        return [tuple(output_shape), tuple(output_shape)]


def main():
    input_1 = Input(shape=(42, 50, 50), dtype='float')
    input_2 = Input(shape=(42, 50, 50), dtype='float')
    output = Complex_QWM_Measurement(100)([input_1, input_2])

    model = Model([input_1, input_2], output)
    model.compile(loss='binary_crossentropy',
                  optimizer='sgd',
                  metrics=['accuracy'])
    model.summary()

    weights = model.get_weights()
    x_1 = np.random.random((16, 42, 50, 50))
    x_2 = np.random.random((16, 42, 50, 50))
    output = model.predict([x_1, x_2])
    print(output)
    for i in range(5):
        xy = x_1[i] + 1j * x_2[i]
        for j in range(3):
            m = weights[0][j, :, 0] + 1j * weights[0][j, :, 1]
            #            print(np.matmul(xy[0] ,np.outer(m,m)))
            #            result = np.absolute(np.trace(np.matmul(xy ,np.outer(m,m))))
            print(np.trace(np.matmul(xy[0], np.outer(m, m))))

    # complex_array = np.random.random((3,5,2))

    # norm_2 = np.linalg.norm(complex_array, axis = (1,2))

    # for i in range(complex_array.shape[0]):
    #     complex_array[i] = complex_array[i]/norm_2[i]
    # # complex_array()= complex_array / norm_2
    # # x_2 = np.random.random((3,5))

    # x = complex_array[:,:,0]
    # x_2 = complex_array[:,:,1]
    # y = np.array([[1],[1],[0]])
    # print(x)
    # print(x_2)

    # for i in range(1000):
    #     model.fit([x,x_2],y)
    # # print(model.get_weights())
    #     output = model.predict([x,x_2])
    #     print(output)
    # # print(output)


if __name__ == '__main__':
    main()
