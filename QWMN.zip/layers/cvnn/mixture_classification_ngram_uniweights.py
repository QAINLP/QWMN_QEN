import numpy as np
from keras import backend as K
from keras.layers import Layer
from keras.models import Model, Input



class ComplexMixture_ngram_uniweights(Layer):

    def __init__(self, average_weights=False, **kwargs):
        # self.output_dim = output_dim
        self.average_weights = average_weights
        super(ComplexMixture_ngram_uniweights, self).__init__(**kwargs)


    def get_config(self):
        config = {'average_weights': self.average_weights}
        base_config = super(ComplexMixture_ngram_uniweights, self).get_config()
        return dict(list(base_config.items())+list(config.items()))

    def build(self, input_shape):



        super(ComplexMixture_ngram_uniweights, self).build(input_shape)  # Be sure to call this somewhere!

    def call(self, inputs):


        
        ndims = len(inputs[0].shape)    #ndims=4
        input_real = K.expand_dims(inputs[0]) #shape: (?, 42, 5, 50,1)
        input_imag = K.expand_dims(inputs[1]) #shape: (?, 42, 5, 50,1)
        
        input_real_transpose = K.expand_dims(inputs[0], axis = ndims-1) #(?, 42, 5, 1,50)
        input_imag_transpose = K.expand_dims(inputs[1], axis = ndims-1) ##(?, 42, 5, 1,50)


        ###
        #output = (input_real+i*input_imag)(input_real_transpose-i*input_imag_transpose)
        ###
        output_real = K.batch_dot(input_real_transpose,input_real, axes = [ndims-1,ndims])+ K.batch_dot(input_imag_transpose, input_imag,axes = [ndims-1,ndims])  #shape: #(?, 42, 5, 50,50)

        output_imag = K.batch_dot(input_real_transpose, input_imag,axes = [ndims-1,ndims])-K.batch_dot(input_imag_transpose,input_real, axes = [ndims-1,ndims])



        # output_real = K.permute_dimensions(output_real, (0,2,3,1))
        # weight = K.permute_dimensions(weight, (0,2,1))
        # print(weight.shape)
        # print(output_real.shape)
        if self.average_weights:
            output_r = K.mean(output_real, axis = ndims-2, keepdims = False)
            output_i = K.mean(output_imag, axis = ndims-2, keepdims = False)

        else:
            #For embedding layer inputs[2] is (None, embedding_dim,1)
            #For test inputs[2] is (None, embedding_dim)
            if len(inputs[2].shape) == ndims-1:
                print("zanzan2", inputs[2].shape)
                weight = K.expand_dims(K.expand_dims(inputs[2]))       #(?, 42, 5, 1,1)
                weight = K.repeat_elements(weight, output_real.shape[-1], axis = ndims-1)#(?, 42, 5, 50,1)
            else:

                print("zanzan",ndims-1,inputs[2].shape)
                weight = K.expand_dims(inputs[2])     #（？，42,1）

            #使用cnm或者qwm-ngram-sigmoid时
            weight = K.repeat_elements(weight, output_real.shape[-1], axis=ndims)     ##(?, 42, 5, 50,50)
            output_real = output_real * weight        #这个是（50，50）和(50,50)的对位相乘
            output_r = K.sum(output_real, axis=2)

            output_imag = output_imag * weight
            output_i = K.sum(output_imag, axis=2)
            print("wahttt",output_real.shape)

        #李赞2020/3/3     每个单词乘以自己对应的softmax权重      有错误，需要改。（需要在这里加一个对权重的ngram处理，不然权重都一样了。(或者将中间的那个密度算子提取出来)）
            # weight = K.repeat_elements(weight, output_real.shape[2], axis = 2)   #?,42,5
            # weight=K.expand_dims(weight)                                         #?,42,5,1
            # weight = K.repeat_elements(weight, output_real.shape[-1], axis=3)    #?,42,5,50
            # weight=K.expand_dims(weight)                                         #?,42,5,50,1
            # weight = K.repeat_elements(weight, output_real.shape[-1], axis=4)    #?,42,5,50,50
            # print("玩呀呀呀呀呀呀呀weight",weight.shape)           #(?,42,5,50,50)
            # print("玩呀呀呀呀呀呀呀real", output_real.shape)
            # output_real = output_real*weight
            # output_r = K.sum(output_real, axis = ndims-2)
            #
            # output_imag = output_imag*weight
            # output_i = K.sum(output_imag, axis = ndims-2)

            print("whatthefuck",output_r.shape)

        #分类时，在使用qwm_ngram的基础上再加上一个可训练的权重
        weight2=K.repeat_elements(inputs[3],50,axis=2)
        weight2 = K.expand_dims(weight2)
        weight2 = K.repeat_elements(weight2,50, axis=3)
        output_r = output_r * weight2
        # output_r = K.sum(output_real, axis=2)
        output_imag = output_i * weight2
        # output_i = K.sum(output_imag, axis=2)
        print("nbnbnb",output_r.shape)
        return [output_r, output_i]

    def compute_output_shape(self, input_shape):
        # print(type(input_shape[1]))
        one_input_shape = list(input_shape[0])
        one_output_shape = []
        for i in range(len(one_input_shape)):
            if not i== len(one_input_shape)-2:
                one_output_shape.append(one_input_shape[i])
        one_output_shape.append(one_output_shape[-1])
#        one_output_shape = [one_input_shape[0], one_input_shape[2], one_input_shape[2]]
#        print(one_output_shape)
#        print('Input shape of mixture layer:{}'.format(input_shape))
#        print([tuple(one_output_shape), tuple(one_output_shape)])
        return [tuple(one_output_shape), tuple(one_output_shape)]


def main():
    input_2 = Input(shape=(3,5), dtype='float')
    input_1 = Input(shape=(3,5), dtype='float')
    weights = Input(shape = (3,), dtype = 'float')
    [output_1, output_2] = ComplexMixture(average_weights = True)([input_1, input_2, weights])


    model = Model([input_1, input_2, weights], [output_1, output_2])
    model.compile(loss='binary_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])
    model.summary()

    x = np.random.random((3,3,5))
    x_2 = np.random.random((3,3,5))
    weights = np.random.random((3,3))
    print("weight",weights)
    output = model.predict([x,x_2, weights])
    print(output)

    # print(x)
    # print(x_2)
    # output = model.predict([x,x_2])
    # print(output)

if __name__ == '__main__':
    main()
