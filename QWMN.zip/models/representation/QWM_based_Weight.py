# -*- coding: utf-8 -*-
#用于返回qwm-based-weight的model代码，与run_qwm_weight.py对应
from keras.layers import Embedding, GlobalMaxPooling1D, GlobalAveragePooling1D, Dense, Masking, Flatten, Dropout, \
    Activation, concatenate, Reshape, Permute

from keras.models import Model, Input, model_from_json, load_model
from keras.constraints import unit_norm
from layers import *
import math
import numpy as np

from keras import regularizers
import keras.backend as K

from layers.concatenation import Concatenation
from layers.cvnn.embedding import phase_embedding_layer, amplitude_embedding_layer
from layers.cvnn.measurement import ComplexMeasurement
from layers.cvnn.mixture import ComplexMixture
from layers.cvnn.multiply import ComplexMultiply
from layers.cvnn.qwm_measurement import Complex_QWM_Measurement
from layers.cvnn.superposition import ComplexSuperposition
from layers.l2_norm import L2Norm
from layers.l2_normalization import L2Normalization
from layers.ngram import NGram
from layers.qwm_ngram import qwm_ngram
from models.BasicModel import BasicModel


class LocalMixtureNN2(BasicModel):

    def initialize(self):
        self.doc = Input(shape=(self.opt.max_sequence_length,), dtype='float32')
        #############################################
        # This parameter should be passed from params
        #        self.ngram = NGram(n_value = self.opt.ngram_value)
        self.ngram = [NGram(9)]  # ngram_value=1,2,3,4   因此[Ngram(1),Ngram(2),Ngram(3),Ngram(4)]
        #############################################

        self.amplitude_embedding = amplitude_embedding_layer(np.transpose(self.opt.lookup_table), None,
                                                             trainable=self.opt.embedding_trainable,
                                                             random_init=self.opt.random_init,
                                                             l2_reg=self.opt.amplitude_l2)
        self.l2_normalization = L2Normalization(axis=3)
        self.l2_normalization_2 = L2Normalization(axis=1)
        self.l2_normalization_3 = L2Normalization(axis=2)

        #使用cnm
        #self.l2_norm =L2Norm(axis=3, keep_dims=False)
        # # #使用qwm_ngram时
        self.l2_norm = qwm_ngram(axis=3, keep_dims=True)

    def __init__(self, opt):
        super(LocalMixtureNN2, self).__init__(opt)

    def build(self):
        output = self.get_representation(self.doc)

        model = Model(self.doc, output)
        return model

    def get_representation(self, doc):

        for n_gram in self.ngram:

            self.inputs = n_gram(doc)

            self.amplitude_encoded = self.amplitude_embedding(self.inputs)

            self.weight =  Activation('softmax')(self.l2_norm(self.amplitude_encoded)) # l2_norm将振幅的按最后一维度。各元素的平方和再开方
            # self.weight = Activation('sigmoid')(self.l2_norm(self.amplitude_encoded))
            # self.weight = self.l2_normalization_3(self.l2_norm(self.amplitude_encoded))

            print("self.weight_shape", self.weight.shape)
            #            self.weight = reshape((-1,self.opt.max_sequence_length,self.opt.ngram_value,1))(self.weight)
        return self.weight

# if __name__ == "__main__":
