# -*- coding: utf-8 -*-
from keras.layers import Embedding, GlobalMaxPooling1D,GlobalAveragePooling1D, Dense, Masking, Flatten,Dropout, Activation,concatenate,Reshape, Permute

from keras.models import Model, Input, model_from_json, load_model
from keras.constraints import unit_norm
from layers import *
import math
import numpy as np

from keras import regularizers
import keras.backend as K

from layers.concatenation import Concatenation
from layers.cvnn.embedding import phase_embedding_layer, amplitude_embedding_layer
from layers.cvnn.measurement import ComplexMeasurement
from layers.cvnn.mixture import ComplexMixture
from layers.cvnn.multiply import ComplexMultiply
from layers.cvnn.qwm_measurement import Complex_QWM_Measurement
from layers.cvnn.superposition import ComplexSuperposition
from layers.l2_norm import L2Norm
from layers.l2_normalization import L2Normalization
from layers.ngram import NGram
from layers.qwm_ngram import qwm_ngram
from models.BasicModel import BasicModel
class LocalMixtureNN(BasicModel):

    def initialize(self):
        self.doc = Input(shape=(self.opt.max_sequence_length,), dtype='float32')
        #############################################
        #This parameter should be passed from params
#        self.ngram = NGram(n_value = self.opt.ngram_value)
        self.ngram = [NGram(n_value = int(n_value)) for n_value in self.opt.ngram_value.split(',')]     #ngram_value=1,2,3,4   因此[Ngram(1),Ngram(2),Ngram(3),Ngram(4)]
        #############################################

        self.amplitude_embedding = amplitude_embedding_layer(np.transpose(self.opt.lookup_table), None, trainable = self.opt.embedding_trainable, random_init = self.opt.random_init,l2_reg=self.opt.amplitude_l2)
        self.phase_embedding= phase_embedding_layer(None, self.opt.lookup_table.shape[0], self.opt.lookup_table.shape[1], trainable = self.opt.embedding_trainable,l2_reg=self.opt.phase_l2)


        self.l2_normalization = L2Normalization(axis = 3)
        self.l2_normalization_2=L2Normalization(axis=1)
        self.l2_normalization_3 = L2Normalization(axis=2)

        #使用cnm
        #self.l2_norm =L2Norm(axis=3, keep_dims=False)
        # #使用qwm_ngram时
        self.l2_norm = qwm_ngram(axis = 3, keep_dims =True)

        self.weight_embedding = Embedding(self.opt.lookup_table.shape[0], 1, trainable = True)
        self.dense = Dense(self.opt.nb_classes, activation=self.opt.activation, kernel_regularizer= regularizers.l2(self.opt.dense_l2))  # activation="sigmoid",
        self.dropout_embedding = Dropout(self.opt.dropout_rate_embedding)
        self.dropout_probs = Dropout(self.opt.dropout_rate_probs)
        #使用CNM时
        #self.projection = ComplexMeasurement(units = self.opt.measurement_size)
        #使用QWM
        self.projection =Complex_QWM_Measurement(units=self.opt.measurement_size)

    def __init__(self,opt):
        super(LocalMixtureNN, self).__init__(opt)


    def build(self):
        #[self.probs_real,self.probs_imag,self.probs_real_back,self.probs_imag_back] = self.get_representation(self.doc)
        [self.probs_real,self.probs_imag] = self.get_representation(self.doc)
        #李赞print("self.probs",self.probs.shape)     #(?,900)
        output1 = self.dense(self.probs_real)      #此处的Dense是全连接层
        output2=self.dense(self.probs_imag)
        #output3 = self.dense(self.probs_real_back)  # 此处的Dense是全连接层
        #output4 = self.dense(self.probs_imag_back)
        output=[output1,output2]
        #李赞print("output.shape",output.shape)      #(?,2)
        model = Model(self.doc,output)
        return model
    
    def get_representation(self,doc):
        
        probs_list = []
        probs_list_real=[]
        probs_list_imag=[]
        probs_list_real_back = []
        probs_list_imag_back = []
        for n_gram in self.ngram:
            #(batch_size,  max_seq_length,n)
            self.inputs = n_gram(doc)
            print("self.inputs.shape",self.inputs.shape)  # (?, 50, 6)
            #(batch_size,  max_seq_length,n,embedding_dim)
            self.phase_encoded = self.phase_embedding(self.inputs)
#            print(self.phase_encoded.shape)
            #(batch_size,  max_seq_length,n,embedding_dim)
            self.amplitude_encoded = self.amplitude_embedding(self.inputs)
#            print(self.amplitude_encoded.shape)

#            self.phase_encoded = reshape((-1,self.opt.max_sequence_length,self.opt.ngram_value,self.opt.lookup_table.shape[1]))(self.phase_encoded)
#            self.amplitude_encoded = reshape((-1,self.opt.max_sequence_length,self.opt.ngram_value,self.opt.lookup_table.shape[1]))(self.amplitude_encoded)

#            self.weight = Activation('softmax')(self.weight_embedding(self.inputs))

            #(batch_size,  max_seq_length,n)
            #print("self.amplitude_encoded的shape",self.amplitude_encoded.shape)  #(?, 42, 1, 50)

            forward = self.l2_norm(self.amplitude_encoded)
            #[forward,backforward]=self.l2_norm(self.amplitude_encoded)
            self.weight1 = Activation('softmax')(forward)  #l2_norm将振幅的按最后一维度。各元素的平方和再开方
            #self.weight2 = Activation('softmax')(backforward)

            #self.weight = Activation('sigmoid')(self.l2_norm(self.amplitude_encoded))
            #self.weight = self.l2_normalization_3(self.l2_norm(self.amplitude_encoded))

            print("self.weight_shape",self.weight1.shape)
#            self.weight = reshape((-1,self.opt.max_sequence_length,self.opt.ngram_value,1))(self.weight)
            self.amplitude_encoded = self.l2_normalization(self.amplitude_encoded)
#            print(self.amplitude_encoded.shape)
        
        
#        self.weight = reshape( (-1,self.opt.max_sequence_length,self.opt.ngram_value))(self.weight)
            #if math.fabs(self.opt.dropout_rate_embedding -1) < 1e-6:
            self.phase_encoded = self.dropout_embedding(self.phase_encoded)
            self.amplitude_encoded = self.dropout_embedding(self.amplitude_encoded)
            
            
            [seq_embedding_real, seq_embedding_imag] = ComplexMultiply()([self.phase_encoded, self.amplitude_encoded])
            if self.opt.network_type.lower() == 'complex_mixture':
                [sentence_embedding_real1, sentence_embedding_imag1]= ComplexMixture()([seq_embedding_real, seq_embedding_imag, self.weight1])      #shape的长度都是3,3,3
                #[sentence_embedding_real2, sentence_embedding_imag2]= ComplexMixture()([seq_embedding_real, seq_embedding_imag, self.weight2])      #shape的长度都是3,3,3

            elif self.opt.network_type.lower() == 'complex_superposition':
                [sentence_embedding_real1, sentence_embedding_imag1]= ComplexSuperposition()([seq_embedding_real, seq_embedding_imag, self.weight1])
                #[sentence_embedding_real2, sentence_embedding_imag2] = ComplexMixture()([seq_embedding_real, seq_embedding_imag, self.weight2])
            else:
#                print('Wrong input network type -- The default mixture network is constructed.')
                [sentence_embedding_real1, sentence_embedding_imag1]= ComplexMixture()([seq_embedding_real, seq_embedding_imag, self.weight1])
                #[sentence_embedding_real2, sentence_embedding_imag2] = ComplexMixture()([seq_embedding_real, seq_embedding_imag, self.weight2])

            #CNM
            #probs_list.append(self.projection([sentence_embedding_real, sentence_embedding_imag]))
            #QWM
            #probs_list.append(self.l2_normalization_2(self.projection([sentence_embedding_real, sentence_embedding_imag])))



#new_model
            [list_real1,list_imag1]=self.projection([sentence_embedding_real1, sentence_embedding_imag1])
            #[list_real2, list_imag2] = self.projection([sentence_embedding_real2, sentence_embedding_imag2])
            probs_list_real.append(list_real1)
            #probs_list_real_back.append(list_real2)
            probs_list_imag.append(list_imag1)
            #probs_list_imag_back.append(list_imag2)
            #
            #probs_list_real.append(self.l2_normalization_2(self.projection([sentence_embedding_real, sentence_embedding_imag])[0]))
            #probs_list_imag.append(self.l2_normalization_2(self.projection([sentence_embedding_real, sentence_embedding_imag])[1]))



            #        probs = Permute((2,1))(probs)
            #        self.probs = reshape((-1,self.opt.max_sequence_length*self.opt.measurement_size))(probs)
#        print(probs_list[0].shape)
#        print(probs_list[1].shape)

        #self.probs = Concatenation(axis = -1)(probs_list)
        self.probs_real=Concatenation(axis = -1)(probs_list_real)
        self.probs_imag=Concatenation(axis = -1)(probs_list_imag)
        #self.probs_real_back = Concatenation(axis=-1)(probs_list_real)
        #self.probs_imag_back = Concatenation(axis=-1)(probs_list_imag)

        print("prprprprprprprrprprp",self.probs_real.shape)        #如果是双向的，(?,42,3000)   3000是500×len(ngram_value)×正反两个方向

        #probs_feature = []
        probs_feature_real=[]
        probs_feature_imag=[]
        #probs_feature_real_back = []
        #probs_feature_imag_back = []

        for one_type in self.opt.pooling_type.split(','):
            if self.opt.pooling_type == 'max':
                #probs = GlobalMaxPooling1D()(self.probs)
                probs_real = GlobalMaxPooling1D()(self.probs_real)
                probs_imag = GlobalMaxPooling1D()(self.probs_imag)
                #probs_real_back = GlobalMaxPooling1D()(self.probs_real_back)
                #probs_imag_back = GlobalMaxPooling1D()(self.probs_imag_back)

            else:
                print('Wrong input pooling type -- The default flatten layer is used.')
                probs_real = Flatten()(self.probs_real)
                probs_imag=Flatten()(self.probs_imag)
                #probs_real_back = Flatten()(self.probs_real_back)
                #probs_imag_back = Flatten()(self.probs_imag_back)

            #李赞 print("dddfffffffffddddddddd",probs.shape)    #(?,900)

            #probs_feature.append(probs)
            probs_feature_real.append(probs_real)
            probs_feature_imag.append(probs_imag)
            #probs_feature_real_back.append(probs_real_back)
            #probs_feature_imag_back.append(probs_imag_back)

        if len(probs_feature_real)>1:
            probs_real = concatenate(probs_feature_real)
        else:
            probs_real = probs_feature_real[0]
            #probs_real_back=probs_feature_real_back[0]

        if len(probs_feature_imag)>1:
            probs_imag = concatenate(probs_feature_imag)
        else:
            probs_imag = probs_feature_imag[0]
            #probs_iamg_back = probs_feature_imag_back[0]
        #if math.fabs(self.opt.dropout_rate_probs -1) < 1e-6:
        probs_real = self.dropout_probs(probs_real)
        probs_imag = self.dropout_probs(probs_imag)
        #probs_real_back = self.dropout_probs(probs_real_back)
        #probs_imag_back = self.dropout_probs(probs_imag_back)
        #李赞 print("eeeeeeeeeeeeeeeeeeee", probs.shape)     #(?,900)
        # return [probs_real,probs_imag,probs_real_back,probs_imag_back]
        return [probs_real,probs_imag]
