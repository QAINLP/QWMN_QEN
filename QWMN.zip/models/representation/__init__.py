from models.representation.RealNN import RealNN
from models.representation.QDNN import QDNN
from models.representation.Ngram_QDNN import Ngram_QDNN
from models.representation.QDNN_CNN import QDNN_CNN
from models.representation.ComplexNN import ComplexNN
from models.representation.QDNNAblation import QDNNAblation
from models.representation.LocalMixtureNN import LocalMixtureNN
from models.representation.QWM_based_Weight import LocalMixtureNN2

def setup(opt):
    print("representation network type: " + opt.network_type)
    if opt.network_type == "real":
        model = RealNN(opt)
    elif opt.network_type == "qdnn":
        model = QDNN(opt)
    elif opt.network_type == "ngram_qdnn":
        model = Ngram_QDNN(opt)
    elif opt.network_type == "qdnn_cnn":
        model=QDNN_CNN(opt)
    elif opt.network_type == "complex":
        model = ComplexNN(opt)
    elif opt.network_type == "local_mixture":
        model = LocalMixtureNN(opt)
    elif opt.network_type == "qwm_based_weight":
        model = LocalMixtureNN2(opt)
    elif opt.network_type == "ablation":
        print("run ablation")
        model = QDNNAblation(opt)
    else:
        raise Exception("model not supported: {}".format(opt.network_type))
    return model
