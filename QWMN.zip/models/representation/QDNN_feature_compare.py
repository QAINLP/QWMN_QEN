# -*- coding: utf-8 -*-
from keras.layers import Embedding, GlobalAveragePooling1D, Dense, Masking, Flatten,Dropout, Activation,Lambda
from models.BasicModel import BasicModel
import keras.backend as K
from keras.models import Model, Input, model_from_json, load_model
from keras.constraints import unit_norm
from layers import *
from layers.cvnn.qwm_measurement_classification import Complex_QWM_Measurement_single

import math
import numpy as np
from keras import regularizers

class QDNN_feature_compare(BasicModel):

    def initialize(self):
        self.doc = Input(shape=(self.opt.max_sequence_length,), dtype='int32')

        self.phase_embedding=phase_embedding_layer(self.opt.max_sequence_length, self.opt.lookup_table.shape[0], self.opt.lookup_table.shape[1], trainable = self.opt.embedding_trainable,l2_reg=self.opt.phase_l2)

        self.amplitude_embedding = amplitude_embedding_layer(np.transpose(self.opt.lookup_table), self.opt.max_sequence_length, trainable = self.opt.embedding_trainable, random_init = self.opt.random_init,l2_reg=self.opt.amplitude_l2)

        self.weight_embedding = Embedding(self.opt.lookup_table.shape[0], 1, trainable = True)   #(17559,1)
        #思路，使用类似ngram-或者qwmgram捕捉局部词义之后，再用这个可训练的权重进行加权。

        self.dense1 = Dense(self.opt.nb_classes, activation=self.opt.activation,name='loss1', kernel_regularizer= regularizers.l2(self.opt.dense_l2))  # activation="sigmoid",
        self.dense2 = Dense(self.opt.nb_classes, activation=self.opt.activation,name='loss2', kernel_regularizer= regularizers.l2(self.opt.dense_l2))  # activation="sigmoid",
        self.dropout_embedding = Dropout(self.opt.dropout_rate_embedding)
        self.dropout_probs = Dropout(self.opt.dropout_rate_probs)
        self.projection = Complex_QWM_Measurement_single(units = self.opt.measurement_size)

    def __init__(self,opt):
        super(QDNN_feature_compare, self).__init__(opt)

    def build(self):
        #单任务
        #probs = self.get_representation(self.doc)
        #多任务
        [probs_real,probs_imag] = self.get_representation(self.doc)
        if self.opt.network_type== "ablation" and self.opt.ablation == 1:
            predictions = ComplexDense(units = self.opt.nb_classes, activation= "sigmoid", init_criterion = self.opt.init_mode)(probs)
            output = GetReal()(predictions)
        else:
            #output=self.dense1(probs)
            output1 = self.dense1(probs_real)  #(?,2)
            output2 = self.dense2(probs_imag)
            def plus_score(inputs):
                x1=inputs[0]
                x2=inputs[1]
                print("x1.shape",x1.shape)
                return K.minimum(x1,x2)
            #output = Lambda(plus_score)([output1, output2])
        model = Model(self.doc, [output1,output2])
        #model = Model(self.doc,output)
        return model

    def get_representation(self,doc):
        self.weight = Activation('softmax')(self.weight_embedding(doc))
        self.phase_encoded = self.phase_embedding(doc)
        self.amplitude_encoded = self.amplitude_embedding(doc)
        print("phase_encoded", self.phase_encoded.shape)
        print("amplitude_encoded", self.amplitude_encoded.shape)
        print("self.weight",self.weight.shape)

        #if math.fabs(self.opt.dropout_rate_embedding -1) < 1e-6:
        self.phase_encoded = self.dropout_embedding(self.phase_encoded)
        self.amplitude_encoded = self.dropout_embedding(self.amplitude_encoded)

        [seq_embedding_real, seq_embedding_imag] = ComplexMultiply()([self.phase_encoded, self.amplitude_encoded])
        print("seq_embedding_real",seq_embedding_real.shape)
        if self.opt.network_type.lower() == 'complex_mixture':
            [sentence_embedding_real, sentence_embedding_imag]= ComplexMixture()([seq_embedding_real, seq_embedding_imag, self.weight])

        elif self.opt.network_type.lower() == 'complex_superposition':
            [sentence_embedding_real, sentence_embedding_imag]= ComplexSuperposition()([seq_embedding_real, seq_embedding_imag, self.weight])

        else:
            print('Wrong input network type -- The default mixture network is constructed.')
            [sentence_embedding_real, sentence_embedding_imag]= ComplexMixture()([seq_embedding_real, seq_embedding_imag, self.weight])
            print("sentence_embedding_real", sentence_embedding_real.shape)
        if self.opt.network_type== "ablation" and self.opt.ablation == 1:
            sentence_embedding_real = Flatten()(sentence_embedding_real)
            sentence_embedding_imag = Flatten()(sentence_embedding_imag)
            probs = [sentence_embedding_real, sentence_embedding_imag]
        # output = Complex1DProjection(dimension = embedding_dimension)([sentence_embedding_real, sentence_embedding_imag])
        else:
            [list_real,list_imag] =  self.projection([sentence_embedding_real, sentence_embedding_imag])

            #单任务
            #probs = self.projection([sentence_embedding_real, sentence_embedding_imag])

            #if math.fabs(self.opt.dropout_rate_probs -1) < 1e-6:
            #probs=self.dropout_probs(probs)
            probs_real = self.dropout_probs(list_real)
            print("n",probs_real.shape)
            probs_imag = self.dropout_probs(list_imag)

        return [probs_real,probs_imag]
        #return probs