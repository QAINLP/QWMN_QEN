# -*- coding: utf-8 -*-
from layers.loss.marginLoss import MarginLoss
from layers.loss.triplet_hinge_loss_transfer import Circle_loss
from models.BasicModel import BasicModel
from keras.layers import Embedding, GlobalMaxPooling1D,Dense, Masking, Flatten,Dropout, Activation,concatenate,Reshape, Permute,Lambda, Subtract,Lambda
from keras.models import Model, Input, model_from_json, load_model, Sequential
from keras.constraints import unit_norm
from layers import *
import math
import numpy as np

from keras import regularizers
import keras.backend as K
from distutils.util import strtobool
from layers import Attention
from models import representation as representation_model_factory
from layers import distance

class SiameseNetwork(BasicModel):

    def initialize(self):
        self.question = Input(shape=(self.opt.max_sequence_length,), dtype='float32')
        self.answer = Input(shape=(self.opt.max_sequence_length,), dtype='float32')
        self.neg_answer_1 = Input(shape=(self.opt.max_sequence_length,), dtype='float32')
        self.answer2 = Input(shape=(self.opt.max_sequence_length,), dtype='float32')
        self.answer3 = Input(shape=(self.opt.max_sequence_length,), dtype='float32')

        distances= [distance.get_distance("AESD.AESD",mean="geometric",delta =0.5,c=1,dropout_keep_prob =self.opt.dropout_rate_probs),
                    distance.get_distance("AESD.AESD",mean="geometric",delta =1,c=1,dropout_keep_prob =self.opt.dropout_rate_probs),
                    distance.get_distance("AESD.AESD",mean="geometric",delta =1.5,c=1,dropout_keep_prob =self.opt.dropout_rate_probs),
                    distance.get_distance("AESD.AESD",mean="arithmetic",delta =0.5,c=1,dropout_keep_prob =self.opt.dropout_rate_probs),
                    distance.get_distance("AESD.AESD",mean="arithmetic",delta =1,c=1,dropout_keep_prob =self.opt.dropout_rate_probs),
                    distance.get_distance("AESD.AESD",mean="arithmetic",delta =1.5,c=1,dropout_keep_prob =self.opt.dropout_rate_probs),
                    distance.get_distance("cosine.Cosine",dropout_keep_prob = self.opt.dropout_rate_probs),
                    distance.get_distance("tensor_comb.TensorComb")
                    ]
                    
        self.distance = distances[self.opt.distance_type]

        
#        self.dense = Dense(self.opt.nb_classes, activation=self.opt.activation, kernel_regularizer= regularizers.l2(self.opt.dense_l2))


        
        self.dense_last =  Dense(self.opt.nb_classes, activation="softmax")
                
    def __init__(self,opt):
        self.representation_model = representation_model_factory.setup(opt)
        super(SiameseNetwork, self).__init__(opt)
        

    def build(self):
        
        if self.opt.match_type == 'pointwise':
            reps = [self.representation_model.get_representation(doc) for doc in [self.question, self.answer]]
            if self.opt.onehot:
                output = self.dense_last(Attention()(reps))
            else:
                output = self.distance(reps)
#          
            model = Model([self.question,self.answer], output)
            
        elif self.opt.match_type == 'pairwise':

            #QWM权重模块测试
            # output = self.representation_model.get_representation(self.question)
            # model = Model([self.question], output)

            [q_rep_real,q_rep_imag] = self.representation_model.get_representation(self.question)
            [answer_real,answer_imag]=self.representation_model.get_representation(self.answer)
            [neg_answer_1_real,neg_answer_1_imag]=self.representation_model.get_representation(self.neg_answer_1)

            #正反向：
            # [q_rep_real,q_rep_imag,q_rep_real_back,q_rep_imag_back] = self.representation_model.get_representation(self.question)
            # [answer_real,answer_imag,answer_real_back,answer_imag_back]=self.representation_model.get_representation(self.answer)
            # [neg_answer_1_real,neg_answer_1_imag,neg_answer_1_real_back,neg_answer_1_imag_back]=self.representation_model.get_representation(self.neg_answer_1)

            #每次投入两个neg答案进行训练
            #[neg_answer_2_real, neg_answer_2_imag] = self.representation_model.get_representation(self.neg_answer_2)

            #print("2020429",q_rep_real.shape)                  #(?,2000) 其中2000是500x4

            print("q_rep",q_rep_real.shape)
            real_score1 = self.distance([q_rep_real, answer_real])      #(?,1)求出问题与正确答案之间的最终表示的距离
            real_score2 = self.distance([q_rep_real, neg_answer_1_real])  #(?,1)求出问题与错误答案之间的最终表示的距离
            #real_score3 = self.distance([q_rep_real, neg_answer_2_real])
            #basic_loss_real = Circle_loss(self.opt.margin,self.opt.gamma)([real_score1,real_score2,real_score3])      #basic_loss (?,1)
            basic_loss_real = Circle_loss(self.opt.margin, self.opt.gamma)([real_score1, real_score2])

            imag_score1=self.distance([q_rep_imag,answer_imag])
            imag_score2 = self.distance([q_rep_imag, neg_answer_1_imag])
            #imag_score3 = self.distance([q_rep_imag, neg_answer_2_imag])
            #basic_loss_imag=Circle_loss(self.opt.margin,self.opt.gamma)([imag_score1,imag_score2,imag_score3])
            basic_loss_imag = Circle_loss(self.opt.margin, self.opt.gamma)([imag_score1, imag_score2])

            #在这里进行两种损失的权重的分配，根据basic_loss_real和basic_loss_imag的L2范数
            def cal_weight(inputs):
                x1 = inputs[0]
                x2 = inputs[1]
                real = K.sqrt(0.00001 + K.sum(x1 ** 2, axis=0, keepdims=False))
                imag = K.sqrt(0.00001 + K.sum(x2 ** 2, axis=0, keepdims=False))
                a=real+imag
                return [real/a,imag/a]
            #[basic_loss_real_weight, basic_loss_imag_weight] = Lambda(cal_weight)([basic_loss_real, basic_loss_imag])

            def real_loss(inputs):
                w=inputs[0]
                loss_real=inputs[1]
                return w*loss_real

            def imag_loss(inputs):
                w=inputs[0]
                loss_imag=inputs[1]
                return w*loss_imag

            def plus_score(inputs):
                x1=inputs[0]
                x2=inputs[1]
                print("x1.shape",x1.shape)
                return K.maximum(x1,x2)

            score=Lambda(plus_score)([real_score1,imag_score1])


#思路1：将正确答案的real和imag求最大值，将错误答案的real和imag求最大值，求这两个的损失？
            #1、距离层面的取最大值。
            # max_score1=Lambda(plus_score)([real_score1,imag_score1])
            # max_score2 = Lambda(plus_score)([real_score2, imag_score2])
            # max_score3 = Lambda(plus_score)([real_score3, imag_score3])
            # basic_loss=Circle_loss(self.opt.margin,self.opt.gamma)([max_score1,max_score2,max_score3])
            # output=[max_score1,basic_loss,basic_loss,basic_loss]
            #2、特征层面的取最大值，然后再求距离。
            # q_rep=Lambda(plus_score)([q_rep_real,q_rep_imag])
            # answer=Lambda(plus_score)([answer_real,answer_imag])
            # neg_answer1=Lambda(plus_score)([neg_answer_1_real,neg_answer_1_imag])
            # neg_answer2=Lambda(plus_score)([neg_answer_2_real, neg_answer_2_imag])
            # score1=self.distance([q_rep, answer])
            # score2 = self.distance([q_rep, neg_answer1])
            # score3 = self.distance([q_rep, neg_answer2])
            # basic_loss = Circle_loss(self.opt.margin, self.opt.gamma)([score1, score2, score3])
            # output = [score1, basic_loss, basic_loss, basic_loss]
            # print("2020429",q_rep.shape) (?,2000)
#思路2：将real和imag拼接起来，然后再求距离。

#思路3：real和imag直接加，再求损失


            # weighted_basic_loss_real=Lambda(real_loss)([basic_loss_real_weight,basic_loss_real])   #(?,1)
            # weighted_basic_loss_imag=Lambda(imag_loss)([basic_loss_imag_weight,basic_loss_imag])


            #反向
            # real_score1_back = self.distance([q_rep_real_back, answer_real_back])  # (?,1)求出问题与正确答案之间的最终表示的距离
            # real_score2_back = self.distance([q_rep_real, neg_answer_1_real_back])  # (?,1)求出问题与错误答案之间的最终表示的距离
            # # real_score3 = self.distance([q_rep_real, neg_answer_2_real])
            # # basic_loss_real = Circle_loss(self.opt.margin,self.opt.gamma)([real_score1,real_score2,real_score3])      #basic_loss (?,1)
            # basic_loss_real_back = Circle_loss(self.opt.margin, self.opt.gamma)([real_score1_back, real_score2_back])
            #
            # imag_score1_back = self.distance([q_rep_imag_back, answer_imag_back])
            # imag_score2_back = self.distance([q_rep_imag_back, neg_answer_1_imag_back])
            # # imag_score3 = self.distance([q_rep_imag, neg_answer_2_imag])
            # # basic_loss_imag=Circle_loss(self.opt.margin,self.opt.gamma)([imag_score1,imag_score2,imag_score3])
            # basic_loss_imag_back = Circle_loss(self.opt.margin, self.opt.gamma)([imag_score1_back, imag_score2_back])
            #
            # score_back = Lambda(plus_score)([real_score1_back, imag_score1_back])
            #
            # score_final = Lambda(plus_score)([score, score_back])
            # loss_real_fianl=Lambda(plus_score)([basic_loss_real, basic_loss_real_back])
            # loss_imag_final=Lambda(plus_score)([basic_loss_imag, basic_loss_imag_back])

            #output=[score,weighted_basic_loss_real,weighted_basic_loss_imag,basic_loss_imag]
            #output = [score_final, basic_loss_real, basic_loss_imag,basic_loss_real_back,basic_loss_imag_back]

            output = [q_rep_real,q_rep_imag,score]
            # np.save('q_rep_real_1',q_rep_real)
            # np.save('q_rep_imag_1', q_rep_imag)
            model = Model([self.question, self.answer, self.neg_answer_1], output)

            #两个neg答案
            #model = Model([self.question, self.answer, self.neg_answer_1,self.neg_answer_2], output)

            #好像因为输入与输出的长度需要一致，不然会报错。所以又添加了两个self.answer2,self.answer3
            #model = Model([self.question, self.answer, self.neg_answer_1,self.answer2,self.answer3], output)



        else:
            raise ValueError('wrong input of matching type. Please input pairwise or pointwise.')
        return model


