# -*- coding: utf-8 -*-
from params import Params
from models import representation as models
from dataset import classification as dataset
from tools import units
from tools.save import save_experiment
import itertools
import argparse
import keras.backend as K
import time
import numpy as np
from layers.loss import *
gpu_count = len(units.get_available_gpus())
dir_path,global_logger = units.getLogger()

def run(params,reader):

    now = int(time.time())
    timeArray = time.localtime(now)
    timeStamp = time.strftime("%Y%m%d_%H.%M.%S", timeArray)
    result_path = 'result/' + params.dataset_name+'/'+ timeStamp + '.txt'
    f = open(result_path, 'a')
    f.write(params.to_string())
    f.close()

    params=dataset.process_embedding(reader,params)
    qdnn = models.setup(params)
    model = qdnn.getModel()

    # model.compile(loss=params.loss, optimizer=units.getOptimizer(name=params.optimizer, lr=params.lr),
    #               metrics=['accuracy'])
    # model.summary()
    # (train_x, train_y), (test_x, test_y), (val_x, val_y) = reader.get_processed_data()
    #
    # # pretrain_x, pretrain_y = dataset.get_sentiment_dic_training_data(reader,params)
    # # model.fit(x=pretrain_x, y = pretrain_y, batch_size = params.batch_size, epochs= 3,validation_data= (test_x, test_y))
    #
    # history = model.fit(x=train_x, y=train_y, batch_size=params.batch_size, epochs=params.epochs,
    #                     validation_data=(test_x, test_y))
    #
    # evaluation = model.evaluate(x=val_x, y=val_y)

    # model.compile(loss = identity_loss,
    #               optimizer = units.getOptimizer(name=params.optimizer,lr=params.lr),
    #               loss_weights=[1.,1.],
    #               metrics=['accuracy'])

    model.compile(loss = {'loss1':'categorical_crossentropy','loss2':'categorical_crossentropy'},
                  optimizer = units.getOptimizer(name=params.optimizer,lr=params.lr),
                  loss_weights={'loss1': 1.,'loss2': 1.},
                  metrics=['accuracy'])

    model.summary()
    #嵌入层参数
    # phase=np.expand_dims(np.load('eval/20201022_14.08.42/amplitude_embedding.npy'),axis=0)
    # ampli=np.expand_dims(np.load('eval/20201022_14.08.42/phase_embedding.npy'),axis=0)
    #
    # model.get_layer('embedding_1').set_weights(phase)
    # model.get_layer('embedding_2').set_weights(ampli)
    # #测量层
    # weight1=np.load('eval/20201022_14.08.42/measurements.npy')
    # weight2 = np.load('eval/20201022_14.08.42/measurements2.npy')
    # model.get_layer('complex_qwm__measurement_single_1').set_weights([weight1,weight2])

    (train_x, train_y),(test_x, test_y),(val_x, val_y) = reader.get_processed_data()

    #pretrain_x, pretrain_y = dataset.get_sentiment_dic_training_data(reader,params)
    #model.fit(x=pretrain_x, y = [pretrain_y,pretrain_y], batch_size = params.batch_size, epochs= 3,validation_data= (test_x, [test_y,test_y]))

    history = model.fit(x=train_x, y = [train_y,train_y], batch_size = params.batch_size, epochs= params.epochs,validation_data= (test_x, [test_y,test_y]))

    evaluation = model.predict(x = test_x)
    # print(len(evaluation))
    # real=np.asarray(evaluation[0])
    # imag=np.asarray(evaluation[1])
    # print(real.shape)
    # print(imag.shape)
    # real_l2norm=np.sum(np.square(real),axis=1)
    # imag_l2norm = np.sum(np.square(imag), axis=1)
    # #保存使用随机和固定初始化两种情况下，实部和虚部的l2范数
    # np.save("SUBJ_random_realpart_l2norm",real_l2norm)
    # np.save("SUBJ_random_imagpart_l2norm",imag_l2norm)
    # c=real_l2norm-imag_l2norm
    # print(real_l2norm)
    # print(imag_l2norm)
    # print(c)
    # print(1000-np.sum(c>0))
    # print(real_l2norm.shape)


    #print(evaluation)
    save_experiment(model, params, evaluation, history, reader)
    #save_experiment(model, params, evaluation, history, reader, config_file)

    return evaluation

grid_parameters ={
        "dataset_name":["MR","TREC","SST_2","SST_5","MPQA","SUBJ","CR"],
        "wordvec_path":["glove/glove.6B.50d.txt"],#"glove/glove.6B.300d.txt"],"glove/normalized_vectors.txt","glove/glove.6B.50d.txt","glove/glove.6B.100d.txt",
        "loss": ["categorical_crossentropy"],#"mean_squared_error"],,"categorical_hinge"
        "optimizer":["rmsprop"], #"adagrad","adamax","nadam"],,"adadelta","adam"
        "batch_size":[15],#,32
        "activation":["sigmoid"],
        "amplitude_l2":[0.0000005], #0.0000005,0.0000001,
        "phase_l2":[0.00000005],
        "dense_l2":[0],#0.0001,0.00001,0],
        "measurement_size" :[1400,1600,1800,2000],#,50100],
        "lr" : [1],#,1,0.01
        "dropout_rate_embedding" : [0.9],#0.5,0.75,0.8,0.9,1],
        "dropout_rate_probs" : [0.9]#,0.5,0.75,0.8,1]
    }

grid_parameters ={
        "dataset_name":["SUBJ"],
        "wordvec_path":["glove/glove.6B.50d.txt"],#"glove/glove.6B.300d.txt"],"glove/normalized_vectors.txt","glove/glove.6B.50d.txt","glove/glove.6B.100d.txt",
        "loss": ["categorical_crossentropy"],#"mean_squared_error"],,"categorical_hinge"
        "optimizer":["rmsprop"], #"adagrad","adamax","nadam"],,"adadelta","adam"
        "batch_size":[16],#,32
        "ngram_value": ["5,7"],
        "network_type":["qdnn"],
        "activation":["sigmoid"],
        "amplitude_l2":[0], #0.0000005,0.0000001,
        "phase_l2":[0.00000005],#0.00000005,0.000000005,
        "dense_l2":[0],#0.0001,0.00001,0],
        "measurement_size" :[8],#,50100],  #200
        "epochs":[10],
        "lr" : [1],#,1,0.01
        "nb_classes" : [2],
        "dropout_rate_embedding" : [0.1],#0.5,0.75,0.8,0.9,1],
        "dropout_rate_probs" : [0.1],#,0.5,0.75,0.8,1],
        "ablation" : [1],
        "filters":[20],
        "filtersize":[10],
        'hidden_units':[20]
    }

if __name__=="__main__":

 # import argparse
    parser = argparse.ArgumentParser(description='running the complex embedding network')
    #parser.add_argument('-gpu_num', action = 'store', dest = 'gpu_num', help = 'please enter the gpu num.',default=gpu_count)
    parser.add_argument('-gpu_num', action='store', dest='gpu_num', help='please enter the gpu num.', default=1)
    parser.add_argument('-gpu', action = 'store', dest = 'gpu', help = 'please enter the gpu num.',default=0)
    args = parser.parse_args()
    
    parameters= [arg for index,arg in enumerate(itertools.product(*grid_parameters.values())) if index%args.gpu_num==args.gpu]

    parameters= parameters[::-1]

    params = Params()
    config_file = 'config/qdnn.ini'    # define dataset in the config
    params.parse_config(config_file)
    for parameter in parameters:
        print(parameter)
        old_dataset = params.dataset_name
        params.setup(zip(grid_parameters.keys(),parameter))

        if old_dataset != params.dataset_name:
            print("switch {} to {}".format(old_dataset,params.dataset_name))
            reader=dataset.setup(params)
            params.reader = reader
        else:
            reader = dataset.setup(params)
            params.reader = reader
#        params.print()
#        dir_path,logger = units.getLogger()
#        params.save(dir_path)
        history,evaluation=run(params,reader)
       # global_logger.info("{} : {:.4f} ".format( params.to_string() ,max(max=(history.history["val_loss1_acc"]),max=(history.history["val_loss2_acc"])) ))
        K.clear_session()


