# -*- coding: utf-8 -*-

"""
使用时，切换datareader
"""

from keras.models import load_model
from params import Params
from dataset import qa
import keras.backend as K
from keras.layers import Lambda
import pandas as pd
from layers.loss import *
from layers.loss.metrics import precision_batch
from tools.units import to_array, getOptimizer, parse_grid_parameters
import argparse
import itertools
from numpy.random import seed
from tensorflow import set_random_seed
import tensorflow as tf
import os
import random
from models import match as models
from tools.evaluation import matching_score, write_to_file
from check_result_in_phone import send_result_to_email

import sklearn
import tensorflow as tf
from keras.models import load_model
import keras.backend as K
from params import Params
from dataset import qa
from layers import *
from layers.l2_normalization import L2Normalization
from layers.cvnn.multiply import ComplexMultiply
from layers.qwm_ngram import qwm_ngram
from layers.cvnn.qwm_measurement import Complex_QWM_Measurement
from layers.loss.triplet_hinge_loss_transfer import Circle_loss

from layers.loss import *
from layers.loss.metrics import precision_batch
from tools.units import to_array
from tools.evaluation import matching_score

import numpy as np
from sklearn import neighbors

import numpy as np

def run(params, reader):
    test_data = reader.getTest(iterable=False, mode='test')
    # print("test_data",test_data)
    qdnn = models.setup(params)
    model = qdnn.getModel()

    performance = []
    data_generator = None
    if 'onehot' not in params.__dict__:
        params.onehot = 0

    elif params.match_type == 'pairwise':
        test_data = [to_array(test_data, reader.max_sequence_length)]
        test_data.append(test_data[0])
        test_data.append(test_data[0])
        model.compile(loss=identity_loss,
                      optimizer=getOptimizer(name=params.optimizer, lr=params.lr),
                      metrics=[precision_batch])
        model.summary()
        # model = load_model('temp/TREC-QA_Model.h5',
        #                    custom_objects={'NGram': NGram, 'L2Normalization': L2Normalization, 'qwm_ngram': qwm_ngram,
        #                                    "Complex_QWM_Measurement": Complex_QWM_Measurement,
        #                                    "ComplexMultiply": ComplexMultiply, "ComplexMixture": ComplexMixture,
        #                                    "Concatenation": Concatenation, "Cosine": Cosine, "Circle_loss": Circle_loss,
        #                                    "identity_loss": identity_loss, "precision_batch": precision_batch})
        # weight=np.load('test_weight.npy')
        weight1 = np.load('embedding_1.npy')
        model.get_layer('embedding_1').set_weights(np.asarray([weight1[0]]))
        weight2 = np.load('embedding_2.npy')
        model.get_layer('embedding_2').set_weights(np.asarray([weight2[0]]))
        weight3 = np.load('complex_qwm__measurement_1.npy')
        print("rest",np.asarray([weight3[1]]).shape)
        model.get_layer('complex_qwm__measurement_1').set_weights([np.squeeze(np.asarray([weight3[0]])),np.squeeze(np.asarray([weight3[1]]))])


    print('Training the network:')
    for i in range(params.epochs):
        print('Test Performance:')
        # print("test_data",test_data)

        y_pred = model.predict(x=test_data)
        np.save('q_rep_real_1',y_pred[0])
        np.save('q_rep_imag_1', y_pred[1])
        print("test",y_pred)
    return performance


if __name__ == '__main__':

    params = Params()
    parser = argparse.ArgumentParser(description='Running the Complex-valued Network for Matching.')
    parser.add_argument('-gpu_num', action='store', dest='gpu_num', help='please enter the gpu num.', default=1)
    parser.add_argument('-gpu', action='store', dest='gpu', help='please enter the gpu num.', default=0)
    parser.add_argument('-config', action='store', dest='config', help='please enter the config path.',
                        default='config/qalocal_pair_trec.ini')
    parser.add_argument('-grid_search', action='store', dest='grid_search', type=bool,
                        help='please enter yes for grid search of parameters.', default=False)
    parser.add_argument('-grid_param_file', action='store', dest='config_grid',
                        help='please enter the file storing parameters for ablation',
                        default='config/test.ini')
    args = parser.parse_args()
    params.parse_config(args.config)

    #   Reproducibility Setting
    seed(params.seed)
    set_random_seed(params.seed)
    random.seed(params.seed)

    session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
    sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
    K.set_session(sess)
    # 创建一个TensorFlow会话并且注册Keras。这意味着Keras将使用我们注册的会话来初始化它在内部创建的所有变量。
    # keras的层和模型都充分兼容tensorflow的各种scope, 例如name scope，device scope和graph scope。

    reader = qa.setup(params)
    performance = run(params, reader)
    K.clear_session()
# model.save("temp/best.h5")
