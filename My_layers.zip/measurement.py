import numpy as np
import tensorflow as tf
from keras import backend as K
from keras.layers import Layer
from keras.models import Model, Input
from keras.constraints import unit_norm
from keras.initializers import orthogonal

from  batch_dot_224 import batch_dot_224


class measurement(Layer):

    def __init__(self, class_num = 2,nums=3, trainable = True,  **kwargs):
        self.class_num = class_num
        self.nums=nums
        self.trainable = trainable
        super(measurement, self).__init__(**kwargs)
        self.measurement_constrain = unit_norm(axis = 1)
        self.measurement_initalizer = orthogonal(seed=None)

    def get_config(self):
        config = {'class_num': self.class_num, 'trainable': self.trainable}
        base_config = super(measurement, self).get_config()
        return dict(list(base_config.items())+list(config.items()))

    def build(self, input_shape):
        self.dim=input_shape[1]
        self.kernel=self.add_weight(name='kernel',
                                      shape=(self.nums,self.dim,1),        #100,1
                                      constraint = self.measurement_constrain,
                                      initializer= self.measurement_initalizer,
                                      trainable=self.trainable)
        # self.kernel2 = self.add_weight(name='kernel2',
        #                                shape=(100, 1),  # 100,1
        #                                constraint=self.measurement_constrain,
        #                                initializer=self.measurement_initalizer,
        #                                trainable=self.trainable)
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        print("lizan",inputs.shape)
        M=batch_dot_224(self.kernel,K.permute_dimensions(self.kernel,[0,2,1]),[2,1])
        print("M",M.shape)
        measured_temp=K.permute_dimensions(K.dot(K.permute_dimensions(inputs,[0,2,1]),M),[0,2,1,3])  #?,5,100,100
        #measured_temp2=K.batch_dot(K.permute_dimensions(K.expand_dims(inputs,1),[0,1,3,2]),measured_temp)
        measured_temp2 = batch_dot_224(measured_temp,K.expand_dims(inputs, 1))
        print("test11",measured_temp2)
        #注意首先矩阵是对称矩阵。所以左乘和右乘一样
        # measured_temp2 = tf.einsum("pqr,bprs->bpqs", K.permute_dimensions(M,[0,2,1]), measured_temp)

        #求测量概率
        M_M_dagger_rho=batch_dot_224(K.expand_dims(inputs,1), measured_temp)
        print("M_M_dagger_rho",M_M_dagger_rho.shape)
        trace=K.expand_dims(K.expand_dims(tf.linalg.trace(M_M_dagger_rho)))
        measured_state=measured_temp2/trace

        # kernel1=self.kernel[0,:,:]
        # print("kernel1",kernel1.shape)
        # kernel2=self.kernel[1,:,:]
        # kernel3=self.kernel[2,:,:]
        # M = K.dot(kernel1, K.transpose(kernel1))
        # rho_temp=K.dot(inputs, M)
        # trace=K.expand_dims(K.expand_dims(tf.trace(rho_temp)))
        # print("trace",trace)
        # rho=rho_temp/trace
        # print("test_meas",rho.shape)
        # # return rho
        # #kernel2
        # M2 = K.dot(kernel2, K.transpose(kernel2))
        # rho_temp2 = K.dot(inputs, M2)
        # trace2 = K.expand_dims(K.expand_dims(tf.trace(rho_temp2)))
        # print("trace", trace2)
        # rho2 = rho_temp2 / trace2
        #
        # #kernel3
        # M3 = K.dot(kernel3, K.transpose(kernel3))
        # rho_temp3 = K.dot(inputs, M3)
        # trace3 = K.expand_dims(K.expand_dims(tf.trace(rho_temp3)))
        # print("trace", trace3)
        # rho3 = rho_temp3 / trace3

        return measured_state

    def compute_output_shape(self, input_shape):

        output=[None,self.nums,self.dim*self.class_num,self.dim*self.class_num]
        return [tuple(output)]
