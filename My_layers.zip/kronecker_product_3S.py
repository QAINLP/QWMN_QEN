import tensorflow as tf
from keras.layers import Layer
from tensorflow.python.ops import array_ops
import keras.backend as K

class kronecker_product_3S(Layer):
    def __init__(self, class_num,**kwargs):
        self.class_num=class_num
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):
        print("kronecker_input",inputs)
        mat1=inputs[0]
        mat2=inputs[1]
        mat3=tf.eye(self.class_num)
        mat1_rsh = K.expand_dims(K.expand_dims(mat1), 2)
        mat2_rsh = K.expand_dims(K.expand_dims(mat1,1), 3)
        print("mat1_rsh",mat1_rsh.shape)
        print("mat2_rsh", mat2_rsh.shape)

        l1, m1, n1 = mat1.get_shape().as_list()
        # mat1_rsh = array_ops.reshape(mat1, [l1,m1, 1, n1, 1])
        l2, m2, n2 = mat2.get_shape().as_list()
        m3, n3 = mat3.get_shape().as_list()
        b=mat1_rsh * mat2_rsh
        print("mat1_rsh * mat2_rsh",b.shape)  #(?, 50, 50, 50, 50)
        # temp=K.reshape(mat1_rsh * mat2_rsh, [-1, m1 * m2, n1 * n2])
        temp = K.reshape(mat1_rsh * mat2_rsh, [-1, 50,50, n1 * n2])
        temp=K.reshape(temp, [-1, 2500, 2500])
        print("bnvn1", temp.shape)
        temp_rsh = K.expand_dims(K.expand_dims(temp), 2)
        mat3_rsh = K.reshape(mat3, [1, m3, 1, n3])
        print("bnvn2", mat3_rsh.shape)
        o=K.reshape(temp_rsh * mat3_rsh, [-1, m1 * m2*m3, n1 * n2*n3])
        print("bnvn3",o.shape)  #bnvn (?, 2500, 2, 2500, 2)
        return o

    def compute_output_shape(self, input_shape):
        dim=input_shape[0][1]
        output_shape=[None,dim*dim*self.class_num,dim*dim*self.class_num]
        return [tuple(output_shape)]

    def build(self, input_shape):
        super().build(input_shape)