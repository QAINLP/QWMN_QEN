import tensorflow as tf
import keras.backend as K
from keras.layers import Input,Layer
from keras.models import Model


class PartialTrace(Layer):

    def __init__(self,class_num,**kwargs):
        self.class_num=class_num
        super().__init__(**kwargs)


    def call(self, inputs, **kwargs):
        dim=inputs.shape[2]//self.class_num
        self.nums=inputs.shape[1]
        # print("self.nums", type(dim))
        # print("self.nums",type(self.nums))
        b1=tf.reshape(inputs,(-1,self.nums,self.class_num,dim,self.class_num,dim))
        c1=K.permute_dimensions(b1,[0,1,5,3,4,2])
        d1=tf.reshape(c1,(-1,self.nums,dim*dim,self.class_num,self.class_num))
        e1=d1[:,:,0:dim*dim:dim+1,:,:]  #(?, 5, 2500, 2, 2)

        f1=K.l2_normalize(K.reshape(K.sum(e1,axis=2),(-1,self.nums*self.class_num*self.class_num)),1) #(?, 20)
        f2=K.reshape(K.sum(e1,axis=2),(-1,self.nums,self.class_num*self.class_num))

        return f2


    def compute_output_shape(self, input_shape):
        output=[None,self.nums*self.class_num*self.class_num]
        return [tuple(output)]


    def build(self, input_shape):
        super().build(input_shape)
