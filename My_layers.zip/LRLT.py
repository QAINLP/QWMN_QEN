# @Time : 2021/12/22 18:41 
# @Author : lizan
# @File : LRLT.py 
# @Software: PyCharm
import tensorflow as tf
import keras.backend as K
from keras.layers import Layer,Input,Dense
from keras.models import Model
import numpy as np

class LRLT(Layer):
    def __init__(self,num_of_classes=2, **kwargs):
        self.num_of_classes=num_of_classes
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):
        input_shapes=inputs.shape
        embedding_dim=input_shapes[1]
        output_dense=Dense(self.num_of_classes*embedding_dim)(inputs)
        #对output_dense做L2归一化
        output_dense=K.l2_normalize(output_dense,1)
        #外积得到密度算子
        out_product=K.batch_dot(K.expand_dims(output_dense,axis=2),K.expand_dims(output_dense,axis=1),axes=[2,1])
        #密度算子LRLT（等价于偏转置）
        #思路：将张量中每一个块矩阵单独取出，做转置，保留每一个张量，然后拼接。
        tensor_list=[]
        r_lb=0
        r_ub=r_lb+embedding_dim
        for i in range(self.num_of_classes):
            tensor_temp_list=[]
            c_lb=0
            c_ub=c_lb+embedding_dim
            for j in range(self.num_of_classes):
                temp_tensor=tf.transpose(out_product[:,r_lb:r_ub,c_lb:c_ub],perm=[0,2,1])
                tensor_temp_list.append(temp_tensor)
                c_lb=c_ub
                c_ub = c_lb + embedding_dim
            tensor_list.append(tensor_temp_list)
            r_lb = r_ub
            r_ub = r_lb + embedding_dim

        concate_tmep_list=[]
        for i in range(self.num_of_classes):
            out_product_partial_transform_raw=K.concatenate(tensor_list[i],2)
            concate_tmep_list.append(out_product_partial_transform_raw)
        out_product_partial_transform=K.concatenate(concate_tmep_list,1)
        print(out_product_partial_transform.shape)
        return out_product_partial_transform


    def compute_output_shape(self, input_shape):
        return super().compute_output_shape(input_shape)

    def build(self, input_shape):
        super().build(input_shape)


if __name__=="__main__":
    embedding_dim=10
    input1=Input(shape=(embedding_dim,),dtype="float32")
    output=LRLT(3)(input1)
    my_model=Model(input1,output)
    my_model.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy'])
    my_model.summary()
    data=np.random.rand(4,10)
    print(data)
    res=my_model.predict(data)
    print(res)
