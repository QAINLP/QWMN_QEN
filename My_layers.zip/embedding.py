import numpy as np
from keras import backend as K
from keras.layers import Layer
from keras.models import Model, Input
from keras.initializers import RandomUniform
from keras.constraints import unit_norm

import math
from dataset.classification.data import get_lookup_table,data_gen
from dataset.classification.data_reader import SSTDataReader
from keras.layers import Embedding
from keras import regularizers

def amplitude_embedding_layer(embedding_matrix, input_shape, trainable = False, random_init = True,l2_reg=0.0000005):
    embedding_dim = embedding_matrix.shape[0]           #50
    vocabulary_size = embedding_matrix.shape[1]         #n
    if(random_init):
        return(Embedding(vocabulary_size,
                                embedding_dim,
                                embeddings_constraint = unit_norm(axis = 1),
                                input_length=input_shape,embeddings_regularizer= regularizers.l2(l2_reg),
                                trainable=trainable))          #n×50
    else:
        return(Embedding(vocabulary_size,
                                embedding_dim,
                                weights=[np.transpose(embedding_matrix)],
                                embeddings_constraint = unit_norm(axis = 1),
                                input_length=input_shape,embeddings_regularizer= regularizers.l2(l2_reg),
                                trainable=trainable))
