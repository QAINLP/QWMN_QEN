import tensorflow as tf
import keras.backend as K
from keras.layers import Layer

#先faltten，再按照规律取对角线的值。
class extract_diag(Layer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):

       return inputs[:,0,0]

    def compute_output_shape(self, input_shape):

        output_shape=[None,2]
        return [tuple(output_shape)]

    def build(self, input_shape):
        super().build(input_shape)