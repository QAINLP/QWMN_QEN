import tensorflow as tf
import keras.backend as K
from keras.layers import Layer

class pure(Layer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):
        self.dim = inputs[1].shape[2]
        weight=K.repeat_elements(inputs[1],self.dim,2)
        a=inputs[0]*weight
        b=K.expand_dims(K.sum(a,1))
        c=K.batch_dot(b,K.permute_dimensions(b,[0,2,1]),[2,1])
        print("pure",c.shape)

        return c

    def compute_output_shape(self, input_shape):
        dim=input_shape[0][2]
        output_shape=[None,dim,dim]
        return [tuple(output_shape)]

    def build(self, input_shape):
        super().build(input_shape)