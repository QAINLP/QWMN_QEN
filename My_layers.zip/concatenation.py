import tensorflow as tf
import keras.backend as K
from keras.layers import Layer

class Concatenation(Layer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):

        input1=inputs[0]
        input2=inputs[1]
        return K.concatenate([input1,input2],axis=1)

    def compute_output_shape(self, input_shape):

        output_shape=[None,8]
        return [tuple(output_shape)]

    def build(self, input_shape):
        super().build(input_shape)