import tensorflow as tf
import keras.backend as K
from keras.layers import Layer
from  batch_dot_224 import batch_dot_224

class mixture(Layer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):
        self.dim=inputs[1].shape[2]
        print("weight",inputs[1].shape)
        input=K.expand_dims(inputs[0])  #? 120 50 1
        print("input",input.shape)
        input_transpose=K.permute_dimensions(input,[0,1,3,2])#? 120 1 50
        print("input_transpose",input_transpose.shape)
        mixture=batch_dot_224(input,input_transpose,[3,2])
        print("mixture",mixture.shape)
        input2=K.repeat_elements(K.repeat_elements(K.expand_dims(inputs[1]),self.dim,3),self.dim,2)  #?,120,50,50
        print("input2",input2.shape)
        m=tf.multiply(input2,mixture)

        mix_sum=K.sum(m,axis=1)  #?,50,50
        return mix_sum

    def compute_output_shape(self, input_shape):
        dim=input_shape[0][2]
        output_shape=[None,dim,dim]
        return [tuple(output_shape)]

    def build(self, input_shape):
        super().build(input_shape)