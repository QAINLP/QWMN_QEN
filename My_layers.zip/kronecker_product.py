import tensorflow as tf
from keras.layers import Layer
import keras.backend as K

class kronecker_product(Layer):
    def __init__(self, class_num,**kwargs):
        self.class_num=class_num
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):
        mat1=inputs
        mat2=tf.eye(self.class_num)
        mat1_rsh = K.expand_dims(K.expand_dims(mat1), 2)
        l1, m1, n1 = mat1.get_shape().as_list()
        m2, n2 = mat2.get_shape().as_list()
        mat2_rsh = K.reshape(mat2, [1, m2, 1, n2])
        o=mat1_rsh * mat2_rsh
        print("dfdf",o.shape)
        m=mat1_rsh * mat2_rsh
        print("mat1_rsh",mat1_rsh.shape)
        print("mat2_rsh", mat2_rsh.shape)
        print("mat1_rsh * mat2_rsh",m.shape)

        return K.reshape(mat1_rsh * mat2_rsh, [-1, m1 * m2, n1 * n2])

    def compute_output_shape(self, input_shape):
        dim=input_shape[1]
        output_shape=[None,dim*self.class_num,dim*self.class_num]
        return [tuple(output_shape)]

    def build(self, input_shape):
        super().build(input_shape)