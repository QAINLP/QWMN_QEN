import numpy as np
import tensorflow as tf
from keras import backend as K
from keras.layers import Layer
from keras.models import Model, Input
from keras.constraints import unit_norm
from keras.initializers import orthogonal


class measurement_3S(Layer):

    def __init__(self, class_num = 2,nums=3, trainable = True,  **kwargs):
        self.class_num = class_num
        self.nums=nums
        self.trainable = trainable
        super(measurement_3S, self).__init__(**kwargs)
        self.measurement_constrain = unit_norm(axis = 1)
        self.measurement_initalizer = orthogonal(seed=None)

    def get_config(self):
        config = {'class_num': self.class_num, 'trainable': self.trainable}
        base_config = super(measurement_3S, self).get_config()
        return dict(list(base_config.items())+list(config.items()))

    def build(self, input_shape):
        self.dim=input_shape[1]
        print("self.dim",self.dim)
        self.kernel=self.add_weight(name='kernel',
                                      shape=(self.nums,self.dim,1),
                                      constraint = self.measurement_constrain,
                                      initializer= self.measurement_initalizer,
                                      trainable=self.trainable)
        # self.kernel2 = self.add_weight(name='kernel2',
        #                                shape=(100, 1),  # 100,1
        #                                constraint=self.measurement_constrain,
        #                                initializer=self.measurement_initalizer,
        #                                trainable=self.trainable)
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        M = K.batch_dot(self.kernel, K.permute_dimensions(self.kernel, [0, 2, 1]), [2, 1])
        measured_temp = K.permute_dimensions(K.dot(K.permute_dimensions(inputs, [0, 2, 1]), M),
                                             [0, 2, 1, 3])  # ?,5,100,100
        # measured_temp2=K.batch_dot(K.permute_dimensions(K.expand_dims(inputs,1),[0,1,3,2]),measured_temp)
        measured_temp2 = K.batch_dot(measured_temp, K.expand_dims(inputs, 1))
        print("measured_temp2",measured_temp2.shape)
        trace=K.expand_dims(K.expand_dims(tf.trace(measured_temp)))
        measured_state=measured_temp2/trace

        # kernel1=self.kernel[0,:,:]
        # print("kernel1",kernel1.shape)
        # kernel2=self.kernel[1,:,:]
        # kernel3=self.kernel[2,:,:]
        # M = K.dot(kernel1, K.transpose(kernel1))
        # rho_temp=K.dot(inputs, M)
        # trace=K.expand_dims(K.expand_dims(tf.trace(rho_temp)))
        # print("trace",trace)
        # rho=rho_temp/trace
        # print("test_meas",rho.shape)
        # # return rho
        # #kernel2
        # M2 = K.dot(kernel2, K.transpose(kernel2))
        # rho_temp2 = K.dot(inputs, M2)
        # trace2 = K.expand_dims(K.expand_dims(tf.trace(rho_temp2)))
        # print("trace", trace2)
        # rho2 = rho_temp2 / trace2
        #
        # #kernel3
        # M3 = K.dot(kernel3, K.transpose(kernel3))
        # rho_temp3 = K.dot(inputs, M3)
        # trace3 = K.expand_dims(K.expand_dims(tf.trace(rho_temp3)))
        # print("trace", trace3)
        # rho3 = rho_temp3 / trace3

        return measured_state

    def compute_output_shape(self, input_shape):

        output=[None,self.nums,self.dim,self.dim]
        return [tuple(output)]
