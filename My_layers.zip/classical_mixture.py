import tensorflow as tf
import keras.backend as K
from keras.layers import Layer

class classical_mixture(Layer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):
        self.dim = inputs[1].shape[2]
        print("weight",inputs[1].shape)
        input1=tf.matrix_diag(K.square(inputs[0]))  #? 120 50 50
        input2 = K.repeat_elements(K.repeat_elements(K.expand_dims(inputs[1]), self.dim, 3), self.dim, 2)  # ?,120,50,50
        mix=K.sum(input1*input2,1)

        return mix

    def compute_output_shape(self, input_shape):
        dim=input_shape[0][2]
        output_shape=[None,dim,dim]
        return [tuple(output_shape)]

    def build(self, input_shape):
        super().build(input_shape)